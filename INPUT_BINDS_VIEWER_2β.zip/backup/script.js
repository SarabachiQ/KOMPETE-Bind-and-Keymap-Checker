function syncCell02toCell01() {
  const gameCells = document.querySelectorAll(".gameCell-02");

  if (!gameCells || gameCells.length === 0) {
    console.warn("gameCells が見つからないよ！");
    return;
  }

  gameCells.forEach((cell, index) => {
    console.log(`Cell ${index} found:`, cell);
  });
}

document.addEventListener("DOMContentLoaded", syncCell02toCell01);