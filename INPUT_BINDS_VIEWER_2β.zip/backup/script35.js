// script35.js

function debugLog(msg) {
  const log = document.getElementById("log");
  if (!log) return;
  const p = document.createElement("div");
  p.textContent = msg;
  log.appendChild(p);
  log.scrollTop = log.scrollHeight;
}

const NUM_BIND_CELLS = 1;

const DUAL_PLACEHOLDER = "… + 🕹L";

const gameCommands = [
  { name: "MOVE F/B/L/R", fixed: "🕹L" },
  { name: "FIRE🔥" },
  { name: "AIM" },
  { name: "MELEE" },
  { name: "RELOAD" },
  { name: "INTERACT" },
  { name: "CROUCH/SLIDE" },
  { name: "SPRINT" },
  { name: "JUMP/EXOSUIT (HOLD)" },
  { name: "EXOSUIT" },
  { name: "SWITCH WEAPON 1" },
  { name: "SWITCH WEAPON 2", fixed: "" },
  { name: "EQUIP MELEE WEAPON", fixed: "LB" },
  { name: "EQUIP UTILITY 1", fixed: "RB" },
  { name: "EQUIP UTILITY 2", fixed: "RB" },
  { name: "EQUIP KAPSULE", fixed: "LB+RB" },
  { name: "LEAN L/R", dual: true },
  { name: "DROP ITEM" },
  { name: "PING" },
  { name: "SWITCH SHOULDER" },
  { name: "TOGGLE SCORECARD" },
  { name: "EMOTE WHEEL" }
];

// 現在の表示モード（初期値は Xbox）
let currentMode = "xbox";

const labelMaps = {
  xbox: {
    X: "X",
    Y: "Y",
    A: "A",
    B: "B",
    LB: "LB",
    RB: "RB",
    LT: "LT",
    RT: "RT",
    L3: "L3",
    R3: "R3",
    M1: "M1",
    M2: "M2",
    M3: "M3",
    M4: "M4",
    "⬆": "⬆",
    "⬇": "⬇",
    "⬅": "⬅",
    "➡": "➡"
  },
  ps: {
    X: "✕",
    Y: "△",
    A: "〇",
    B: "□",
    LB: "L1",
    RB: "R1",
    LT: "L2",
    RT: "R2",
    L3: "L3",
    R3: "R3",
    M1: "M1",
    M2: "M2",
    M3: "M3",
    M4: "M4",
    "⬆": "↑",
    "⬇": "↓",
    "⬅": "←",
    "➡": "→"
  },
  switch: {
    X: "XX",
    Y: "YY",
    A: "AA",
    B: "BB",
    LB: "L",
    RB: "R",
    LT: "ZL",
    RT: "ZR",
    L3: "L3",
    R3: "R3",
    M1: "M1",
    M2: "M2",
    M3: "M3",
    M4: "M4",
    "⬆": "↑",
    "⬇": "↓",
    "⬅": "←",
    "➡": "→"
  }
};

// ボタンの形状
const roundBtn = ["X", "Y", "A", "B", "❐", "≡", "📷", "⬡"];
const oblongBtn = ["LB", "LT", "RB", "RT", "L3", "R3"];
const squareBtn = ["⬆", "⬇", "⬅", "➡"];
const macroBtn = ["M1", "M2", "M3", "M4"];

// 各ボタンの使用先プール
const gameBtnPool = [
  "X", "Y", "A", "B", "⬆", "⬇", "⬅", "➡",
  "LB", "RB", "LT", "RT", "L3", "R3",
  "❐", "≡", "📷", "⬡",
  "L🕹↑", "L🕹↓", "L🕹←", "L🕹→"
];

const keymapBtnPool = [
  "X", "Y", "A", "B", "⬆", "⬇", "⬅", "➡",
  "LB", "RB", "LT", "RT", "L3", "R3",
  "❐", "≡", "📷", "⬡", "M1", "M2", "M3", "M4"
];

const gameBody = document.getElementById("gameBody");
const keymapBody = document.getElementById("keymapBody");
const btnGameBody = document.getElementById("btnGameBody");
const btnKeymapBody = document.getElementById("btnKeymapBody");

let selectedCell = null; let selectedCommand = null; let aimButton = ""; let currentGamePool = [...gameBtnPool]; let currentKeymapPool = [...keymapBtnPool];
// セル管理用マップ
const commandCellMap = new Map();
// ゲームテーブルの作成
function createGameTable() {
  gameCommands.forEach((cmd) => {
    const row = document.createElement("tr");
    row.setAttribute("draggable", true);

    const nameCell = document.createElement("td");
    nameCell.textContent = cmd.name;
    if (cmd.fixed !== undefined) {
      nameCell.classList.add("fixed-cell");
    }
    row.appendChild(nameCell);

    for (let i = 0; i < NUM_BIND_CELLS; i++) {
      const cell = document.createElement("td");
      if (cmd.fixed !== undefined) {
        cell.textContent = cmd.fixed;
        cell.classList.add("fixed-cell");
      } else if (cmd.dual) {
        cell.textContent = DUAL_PLACEHOLDER;
        cell.classList.add("dual");
      } else {
        cell.classList.add("btn-cell5");
        cell.addEventListener("click", () => handleCellClick(cell, cmd));
      }

      commandCellMap.set(cell, cmd);
      row.appendChild(cell);
    }

    gameBody.appendChild(row);
  });
}

// --- ⑤ 各種 DOM・表示処理 ---
const container1 = document.getElementById("container1");
const container2 = document.getElementById("container2");
const poolWindow5 = document.getElementById("container5");
const poolWindow6 = document.getElementById("container6");

// キーマップテーブルの作成
function createKeymapTable() {
  keymapBtnPool.forEach((btn) => {
    const row = document.createElement("tr");
    const toCell = document.createElement("td");
    toCell.classList.add("btn-cell6", "btn-cell6-01");
    row.appendChild(toCell);

    for (let i = 0; i < 3; i++) {
      const cell = document.createElement("td");
      const subClass = `btn-cell6-0${i + 2}`;
      cell.classList.add("btn-cell6", subClass);

      if (i === 0) {
        if (!commandCellMap.has(btn)) {
          commandCellMap.set(btn, []);
        }
        cell.addEventListener("click", () => handleCellClick(cell, btn));
        commandCellMap.get(btn).push(cell);
      }

      row.appendChild(cell);
    }

    keymapBody.appendChild(row);
  });
  syncToColumnFromGameBody();
}

function rebuildBtnTable(master, current, tbody, type) {
  tbody.innerHTML = "";
  for (let i = 0; i < master.length; i += 2) {
    const row = document.createElement("tr");

    for (let j = 0; j < 2; j++) {
      const idx = i + j;
      const btn = master[idx];
      if (!btn) continue;

      const cell = document.createElement("td");
      cell.className = "btn";

      const shapeClass = getBtnShapeClass(btn);
      const colorClass = "btn-" + btn;

      const innerBtn = document.createElement("div");
      innerBtn.className = `inner-btn ${shapeClass} ${colorClass}`;
      innerBtn.textContent = btn;

      if (btn === "⬡") {
        innerBtn.style.opacity = "1.0";
        cell.classList.add("fixed-cell");
      } else

        if (current.includes(btn)) {
        innerBtn.style.opacity = "0.9";
        cell.addEventListener("click", () => {
          if (!selectedCell) return;

          // 1. コマンドセル側の元のボタン取得
          const oldEl = selectedCell.querySelector(".inner-btn");
          let oldVal;

          if (oldEl) {
            oldVal = oldEl.dataset.original || getOriginalLabel(oldEl.textContent.trim());
          } else {
            oldVal = getOriginalLabel(selectedCell.textContent.trim());
          }

          // 2. コマンドセルに新しいボタンを配置
          updateCommandCells(selectedCommand, btn);

          // 3. oldVal を Btn Pool に戻す（重複防止）
          if (oldVal && !current.includes(oldVal)) {
            current.push(oldVal);
          }

          // 4. 今クリックされたボタンを Btn Pool から削除
          const index = current.indexOf(btn);
          if (index > -1) current.splice(index, 1);

          // 5. 終了処理
          selectedCell.classList.remove("highlight");
          selectedCell = null;
          selectedCommand = null;

          // 6. 再描画
          rebuildBtnTable(master, current, tbody, type);
        });
      } else {
        innerBtn.style.opacity = "0.15";
        cell.addEventListener("click", () => {
          if (!selectedCell) return;

          const valEl = selectedCell.querySelector(".inner-btn");
          const val = valEl ? valEl.textContent.trim(): selectedCell.textContent.trim();

          if (val && !current.includes(val)) {
            current.push(val);
          }

          updateCommandCells(selectedCommand, "");

          selectedCell.classList.remove("highlight");
          selectedCell = null;
          selectedCommand = null;

          rebuildBtnTable(master, current, tbody, type);
        });
      }

      cell.appendChild(innerBtn);
      row.appendChild(cell);
    }

    tbody.appendChild(row);
  }
}

function syncToColumnFromGameBody() {
  const rows1 = container1.querySelectorAll("tr");
  const rows2 = container2.querySelectorAll("tr");

  rows1.forEach((row1, rowIndex) => {
    const cells1 = row1.querySelectorAll("td");
    const row2 = rows2[rowIndex];
    if (!row2) return;

    const cells2 = row2.querySelectorAll("td");
    const sourceCell = cells1[1]; // container1の2列目
    const targetCell = cells2[0]; // container2の1列目

    if (!sourceCell || !targetCell) return;

    targetCell.innerHTML = ""; // 初期化
    targetCell.className = "btn-cell5"; // 一度クラスをリセットしてから…

    // ✅ クラス（状態）を同期
    if (sourceCell.classList.contains("fixed-cell")) {
      targetCell.classList.add("fixed-cell");
    }
    if (sourceCell.classList.contains("dual")) {
      targetCell.classList.add("dual");
    }
    if (sourceCell.classList.contains("half-transparent")) {
      targetCell.classList.add("half-transparent");
    }

    // ✅ 中身の同期
    const btn = sourceCell.querySelector("button, .inner-btn");
    if (btn) {
      const clone = btn.cloneNode(true);
      const wrapper = document.createElement("div");
      wrapper.style.position = "relative";
      wrapper.style.width = "100%";
      wrapper.style.height = "100%";
      wrapper.appendChild(clone);
      targetCell.appendChild(wrapper);
    } else {
      // fixed-cell や dual でテキストのみの場合
      targetCell.textContent = sourceCell.textContent.trim();
    }
  });
}

// クリックイベント処理
function handleCellClick(cell, cmd) {
  console.log("selectedCell:", selectedCell);
  console.log("clicked cell:", cell);
  console.log("selectedCell === cell?", selectedCell === cell);
  console.log("parent row HTML:", cell.parentElement.outerHTML);
  console.log("handleCellClick called:");
  console.log("- cell:", cell);
  console.log("- cellIndex:", cell.cellIndex);
  console.log("- parent row HTML:", cell.parentElement.innerHTML);

  const isFromContainer1 = selectedCell && container1.contains(selectedCell);
  const isFromContainer2 = selectedCell && container2.contains(selectedCell);
  const isToContainer1 = container1.contains(cell);
  const isToContainer2 = container2.contains(cell);

  if (selectedCell === cell) {
    selectedCell.classList.remove("highlight");
    selectedCell = null;
    selectedCommand = null;
    return;
  }

  if (selectedCell) {
    const oldVal = selectedCell.textContent;
    const newVal = cell.textContent;
    updateCommandCells(selectedCommand, newVal);
    updateCommandCells(cmd, oldVal);
    selectedCell.classList.remove("highlight");
    selectedCell = null;
    selectedCommand = null;
  } else {
    selectedCell = cell;
    selectedCommand = cmd;
    cell.classList.add("highlight");
  }
  
      // ポップアップ表示処理
    if (cell.classList.contains("btn-cell5")) {
      const container5 = document.getElementById("container5");
      const container6 = document.getElementById("container6");
      if (!container5.classList.contains("show")) {
        console.log(">> btn-cell5 clicked. Show container5.");
        container6.classList.remove("show");
        container5.classList.add("show");
        container1.style.zIndex = 50;
        container2.style.zIndex = 40;
        container5.style.zIndex = 30;
        alignPopup(container3, container5);
      }
    }

    if (cell.classList.contains("btn-cell6") && cell.classList.contains("btn-cell6-02")) {
      const container5 = document.getElementById("container5");
      const container6 = document.getElementById("container6");
      if (!container6.classList.contains("show")) {
        console.log(">> btn-cell6 clicked. Show container6.");
        container5.classList.remove("show");
        container6.classList.add("show");
        container1.style.zIndex = 50;
        container2.style.zIndex = 40;
        container6.style.zIndex = 20;
        alignPopup(container3, container6);
      }
    }
/*
  // ✅ c列目セルは container1 / container2 どちらでもクリック禁止
  const isFirstColumn = cell.cellIndex === 0;
  if (isFirstColumn) {
    console.log("❌ クリック禁止: 1列目セルは無視します");
    return false;
  }

  // ✅ container1の2列目、container2の2列目のみ選択可能
  const isSecondColumn = cell.cellIndex === 1;
  const isValidTarget =
    (isToContainer1 && isSecondColumn) || (isToContainer2 && isSecondColumn);

  if (!isValidTarget) {
    console.log("❌ クリック禁止: 2列目以外は無視します");
    return false;
  }

  if (selectedCell === cell) {
    console.log("選択中セルをもう一度クリック → 選択解除");
    selectedCell.classList.remove("highlight");
    selectedCell = null;
    return false;
  }

  if ((isFromContainer1 && isToContainer2) || (isFromContainer2 && isToContainer1)) {
    console.log("❌ container1 ⇄ container2 間の移動は禁止");
    selectedCell.classList.remove("highlight");
    selectedCell = cell;
    cell.classList.add("highlight");
    return false;
  }

  if (selectedCell) {
    console.log("セルの値を交換します");
    const oldVal = selectedCell.textContent.trim();
    const newVal = cell.textContent.trim();

    updateCommandCells(selectedCell, newVal);
    updateCommandCells(cell, oldVal);

    selectedCell.classList.remove("highlight");
    selectedCell = null;
    return true;
  } else {
    console.log("セルを選択します");
    selectedCell = cell;
    cell.classList.add("highlight");
    return false;
  }
*/
}

// セルの更新
function updateCommandCells(cell, val) {
  const isBtn = keymapBtnPool.includes(val) || gameBtnPool.includes(val);

  const createBtnEl = (value) => {
    const original = getOriginalLabel(value);
    const shapeClass = getBtnShapeClass(original);
    const colorClass = "btn-" + original;
    const label = labelMaps[currentMode]?.[original] ?? original;

    const wrapper = document.createElement("div");
    wrapper.style.position = "relative";
    wrapper.style.width = "100%";
    wrapper.style.height = "100%";

    const btnEl = document.createElement("div");
    btnEl.className = `inner-btn ${shapeClass} ${colorClass}`;
    btnEl.textContent = label;
    btnEl.dataset.original = original;

    wrapper.appendChild(btnEl);
    return wrapper;
  };

  cell.innerHTML = "";
  if (isBtn) {
    cell.appendChild(createBtnEl(val));
  } else {
    cell.textContent = val;
  }

  if (cell.textContent.trim() === "AIM") {
    aimButton = val;
    updateLeanBinds();
  }

  if (["RELOAD", "INTERACT"].includes(cell.textContent.trim())) {
    const groupVal = val;
    ["RELOAD", "INTERACT"].forEach((key) => {
      if (!commandCellMap.has(key)) return;
      commandCellMap.get(key).forEach((c) => {
        c.innerHTML = "";
        if (isBtn) {
          c.appendChild(createBtnEl(groupVal));
        } else {
          c.textContent = groupVal;
        }
      });
    });
  }
}

// LEANボタンのバインディング
function updateLeanBinds() {
  const cells = commandCellMap.get("LEAN L/R");
  if (cells) {
    cells.forEach((c) => {
      c.textContent = (aimButton || "…") + " + 🕹L";
    });
  }
}

function getBtnShapeClass(label) {
  if (["⬆", "⬇", "⬅", "➡", "↑", "↓", "←", "→"].includes(label)) return "square";
  if (["LT", "RT", "L2", "R2", "ZL", "ZR"].includes(label)) return "trigger";
  if (["LB", "RB", "L1", "R1"].includes(label)) return "shoulder";
  if (["L3", "R3"].includes(label)) return "stick";
  return "face";
}

// ボタンのラベル変換用関数
function getOriginalLabel(label) {
  for (const mode in labelMaps) {
    for (const key in labelMaps[mode]) {
      if (labelMaps[mode][key] === label) {
        return key;
      }
    }
  }
  return label;
}

function updateButtonLabels(mode) {
  const btns = document.querySelectorAll(".inner-btn");

  btns.forEach((btn) => {
    let original = btn.dataset.original;

    // 初回のみ保存
    if (!original) {
      original = getOriginalLabel(btn.textContent.trim());
      btn.dataset.original = original;
    }

    const mapped = labelMaps[mode]?.[original];
    btn.textContent = mapped ?? original;
  });
}

// ポップアップ表示調整
function alignPopup(referenceEl, popupEl) {
  const rect = referenceEl.getBoundingClientRect();
  popupEl.style.left = `${rect.right + 10}px`;
  popupEl.style.top = `${rect.top}px`;
  popupEl.classList.add("show");
}

// プールを閉じる処理
function closeGameBtnPool() {
  const popup = document.getElementById("container5");
  if (popup) popup.classList.remove("show");
}

function closeKeymapBtnPool() {
  const popup = document.getElementById("container6");
  if (popup) popup.classList.remove("show");
}

// 初期化処理
document.addEventListener("DOMContentLoaded", () => {
  const container1 = document.getElementById("container1");
  const container2 = document.getElementById("container2");
  const container3 = document.getElementById("container3");

  createGameTable();
  createKeymapTable();

  document.addEventListener("click", (event) => {
    const cell = event.target.closest(".btn-cell5, .btn-cell6");
    if (!cell) return;

    const didSwap = handleCellClick(cell);

    if (didSwap) return;

    event.stopPropagation();
    event.preventDefault();


  });

  // クリックでポップアップ閉じる（除外要素を除く）
  document.addEventListener("click", (event) => {
    if (
      !event.target.closest(
        "#container5, .btn-cell5, #container6, .btn-cell6-01, .btn-cell6-02, .btn-cell6-03, .btn-cell6-04"
      )
    ) {
      closeGameBtnPool();
      closeKeymapBtnPool();
    }
  });
});