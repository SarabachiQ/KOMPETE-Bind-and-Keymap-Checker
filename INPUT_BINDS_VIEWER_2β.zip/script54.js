// script55.js
/*
function debugLog(msg) {
  const log = document.getElementById("log"); if (!log) return; const p = document.createElement("div"); p.textContent = msg; log.appendChild(p); log.scrollTop = log.scrollHeight;
}
*/
const NUM_BIND_CELLS = 1;
const DUAL_PLACEHOLDER = "…" + " +" + "🕹L";

const gameCommands = [{
  name: "MOVE F/B/L/R",
  fixed: "🕹L"
}, {
  name: "FIRE🔥"
}, {
  name: "AIM"
}, {
  name: "MELEE"
}, {
  name: "RELOAD"
}, {
  name: "INTERACT"
}, {
  name: "CROUCH/SLIDE"
}, {
  name: "SPRINT"
}, {
  name: "JUMP/EXOSUIT (HOLD)"
}, {
  name: "EXOSUIT"
}, {
  name: "SWITCH WEAPON 1"
}, {
  name: "SWITCH WEAPON 2",
  fixed: "NUL"
}, {
  name: "EQUIP MELEE WEAPON",
  fixed: "LB"
}, {
  name: "EQUIP UTILITY 1",
  fixed: "RB"
}, {
  name: "EQUIP UTILITY 2",
  fixed: "RB"
}, {
  name: "EQUIP KAPSULE",
  fixed: "LB+RB"
}, {
  name: "LEAN L/R",
  dual: true
}, {
  name: "DROP ITEM"
}, {
  name: "PING"
}, {
  name: "SWITCH SHOULDER"
}, {
  name: "TOGGLE SCORECARD"
}, {
  name: "EMOTE WHEEL"
}];

const keymapCommands = [{
  name: "MOVE F/B/L/R",
  fixed: "🕹L"
}, {
  name: "FIRE🔥"
}, {
  name: "AIM"
}, {
  name: "MELEE"
}, {
  name: "RELOAD"
}, {
  name: "INTERACT"
}, {
  name: "CROUCH/SLIDE"
}, {
  name: "SPRINT"
}, {
  name: "JUMP/EXOSUIT (HOLD)"
}, {
  name: "EXOSUIT"
}, {
  name: "SWITCH WEAPON 1"
}, {
  name: "SWITCH WEAPON 2",
  fixed: "NUL"
}, {
  name: "EQUIP MELEE WEAPON",
  fixed: "LB"
}, {
  name: "EQUIP UTILITY 1",
  fixed: "RB"
}, {
  name: "EQUIP UTILITY 2",
  fixed: "RB"
}, {
  name: "EQUIP KAPSULE",
  fixed: "LB+RB"
}, {
  name: "LEAN L/R",
  dual: true
}, {
  name: "DROP ITEM"
}, {
  name: "PING"
}, {
  name: "SWITCH SHOULDER"
}, {
  name: "TOGGLE SCORECARD"
}, {
  name: "EMOTE WHEEL"
}];

const masterBtn = {
  btn1: { label: "X", shape: "round" },
  btn2: { label: "Y", shape: "round" },
  btn3: { label: "A", shape: "round" },
  btn4: { label: "B", shape: "round" },
  btn5: { label: "LB", shape: "oblong" },
  btn6: { label: "RB", shape: "oblong" },
  btn7: { label: "LT", shape: "oblong" },
  btn8: { label: "RT", shape: "oblong" },
  btn9: { label: "L3", shape: "oblong" },
  btn10: { label: "R3", shape: "oblong" },
  
  btn11: { label: "❏", shape: "round" },
  btn12: { label: "≡", shape: "round" },
  btn13: { label: "📷", shape: "round" },
  btn14: { label: "⬡", shape: "round" },
  
  btn15: { label: "⬆", shape: "square" },
  btn16: { label: "⬇", shape: "square" },
  btn17: { label: "⬅", shape: "square" },
  btn18: { label: "➡", shape: "square" },
  
  btn19: { label: "✕", shape: "round" },
  btn20: { label: "△", shape: "round" },
  btn21: { label: "〇", shape: "round" },
  btn22: { label: "□", shape: "round" },
  
  btn23: { label: "L1", shape: "oblong" },
  btn24: { label: "R1", shape: "oblong" },
  btn25: { label: "L2", shape: "oblong" },
  btn26: { label: "R2", shape: "oblong" },
  
  btn27: { label: "ZL", shape: "oblong" },
  btn28: { label: "ZR", shape: "oblong" },
  
  btn29: { label: "XX", shape: "round" },
  btn30: { label: "YY", shape: "round" },
  btn31: { label: "AA", shape: "round" },
  btn32: { label: "BB", shape: "round" },
  
  btn33: { label: "L", shape: "oblong" },
  btn34: { label: "R", shape: "oblong" },
  btn35: { label: "ZL", shape: "oblong" },
  btn36: { label: "ZR", shape: "oblong" },
  
  btn37: { label: "⇧🕹L", shape: "joystick" },
  btn38: { label: "⇩🕹L", shape: "joystick" },
  btn39: { label: "⇦🕹L", shape: "joystick" },
  btn40: { label: "⇨🕹L", shape: "joystick" },
  
  btn41: { label: "M1", shape: "macro" },
  btn42: { label: "M2", shape: "macro" },
  btn43: { label: "M3", shape: "macro" },
  btn44: { label: "M4", shape: "macro" },
  
  btn45: { label: "+", shape: "round" },
  btn46: { label: "…", shape: "round" },
  btn47: { label: "　", shape: "round" },
  btn48: { label: "-", shape: "round" }
};
/*
// 抽出して配列にする例
const roundBtn = Object.values(masterBtn)
  .filter(btn => btn.shape === "round")
  .map(btn => btn.label);

const oblongBtn = Object.values(masterBtn)
  .filter(btn => btn.shape === "oblong")
  .map(btn => btn.label);

const squareBtn = Object.values(masterBtn)
  .filter(btn => btn.shape === "square")
  .map(btn => btn.label);

const joystickBtn = Object.values(masterBtn)
  .filter(btn => btn.shape === "joystick")
  .map(btn => btn.label);

const macroBtn = Object.values(masterBtn)
  .filter(btn => btn.shape === "macro")
  .map(btn => btn.label);
*/
const labelMaps = {
  modeXbox: {
    X: "X",
    Y: "Y",
    A: "A",
    B: "B",
    LB: "LB",
    RB: "RB",
    LT: "LT",
    RT: "RT",
    L3: "L3",
    R3: "R3",
    "❏": "❏",
    "≡": "≡",
    "📷": "📷",
    "⬡": "⬡",
    "⬆": "⬆",
    "⬇": "⬇",
    "⬅": "⬅",
    "➡": "➡"
  },
  modePlaystation: {
    "X": "✕",
    "Y": "△",
    "A": "〇",
    "B": "□",
    "LB": "L1",
    "RB": "R1",
    "LT": "L2",
    "RT": "R2",
    "L3": "L3",
    "R3": "R3",
    "❏": "❏",
    "≡": "≡",
    "📷": "📷",
    "⬡": "⬡",
    "⬆": "↑",
    "⬇": "↓",
    "⬅": "←",
    "➡": "→"
  },
  modeSwitch: {
    "X": "XX",
    "Y": "YY",
    "A": "AA",
    "B": "BB",
    "LB": "L",
    "RB": "R",
    "LT": "ZL",
    "RT": "ZR",
    "L3": "L3",
    "R3": "R3",
    "❏": "❏",
    "≡": "≡",
    "📷": "📷",
    "⬡": "⬡",
    "⬆": "↑",
    "⬇": "↓",
    "⬅": "←",
    "➡": "→"
  }
};

const roundBtn = ["X", "Y", "A", "B", "❐", "≡", "📷", "⬡"];
const oblongBtn = ["LB", "LT", "RB", "RT", "L3", "R3"];
const squareBtn = ["⬆", "⬇", "⬅", "➡"];
const joystickBtn = ["⇧🕹L", "⇩🕹L", "⇦🕹L", "⇨🕹L"];
const macroBtn = ["M1", "M2", "M3", "M4"];

const btnGamePool = [
  "X", "Y", "A", "B", "⬆", "⬇", "⬅", "➡",
  "LB", "RB", "LT", "RT", "L3", "R3",
  "❐", "≡", "📷", "⬡",
  "⇧🕹L", "⇩🕹L", "⇦🕹L", "⇨🕹L"
];
const btnKeymapPool2 = [
  "X", "Y", "A", "B", "⬆", "⬇", "⬅", "➡",
  "LB", "RB", "LT", "RT", "L3", "R3",
  "❐", "≡", "📷", "⬡", "M1", "M2", "M3", "M4"
];
const btnKeymapPool3 = [
  "X", "Y", "A", "B", "⬆", "⬇", "⬅", "➡",
  "LB", "RB", "LT", "RT", "L3", "R3",
  "❐", "≡", "📷", "⬡", "M1", "M2", "M3", "M4"
];
// DOM要素取得
const gameBody0001 = document.getElementById("gameBody");
const btnGamePool0001 = document.getElementById("btnGamePool");
const poolWindow0005 = document.getElementById("poolWindow5");

const keymapBody0002 = document.getElementById("keymapBody2");
const btnKeymapPool0002 = document.getElementById("btnKeymapPool2");
const poolWindow0002 = document.getElementById("poolWindow2");

const keymapBody0003 = document.getElementById("keymapBody3");
const btnKeymapPool0003 = document.getElementById("btnKeymapPool3");
const poolWindow0003 = document.getElementById("poolWindow3");

const container0001 = document.getElementById("container1");
const container0002 = document.getElementById("container2");
const container0003 = document.getElementById("container");

const commandCellMap = new Map();
const keymapCellMap = new Map();

let defaultMode = "modeXbox";
// 状態変数（Body と Pool 両方を管理）
let gameBody0001Current = []; // gameBody の配置状態（初期は空でOK）
let btnGamePool0001Current = [...btnGamePool]; // ゲームプールの初期状態（マスター配列のコピー）
let keymapBody0002Current = []; // keymapBody2 の配置状態
let btnKeymapPool0002Current = [...btnKeymapPool2]; // キーマップ2プールの初期状態
let keymapBody0003Current = []; // keymapBody3 の配置状態
let btnKeymapPool0003Current = [...btnKeymapPool3]; // キーマップ3プールの初期状態

let selectedCell = null;
let selectedCommand = null;
let selectedAimBtn = "";
let selectedColIndex = null;
let selectedBodyId = null; // "gameBody0001", "keymapBody0002", "keymapBody0003" のいずれかを保持
let selectedCellClass = null; // ★ クラスベース管理に変更

function saveButtonState() {
  const data = {
    gameBody: [],
    keymapBody2: [],
    keymapBody3: []
  };
  
  Array.from(gameBody.querySelectorAll("tr")).forEach(row => {
    const rowData = [];
    Array.from(row.querySelectorAll("td")).forEach(cell => {
      const btnDiv = cell.querySelector("div.inner-btn");
      rowData.push({
        text: btnDiv ? btnDiv.textContent : cell.textContent,
        className: cell.className,
        btnClassName: btnDiv ? btnDiv.className : null,
        dataCmd: cell.dataset.cmd || null,
        dataCol: cell.dataset.col || null,
      });
    });
    data.gameBody.push(rowData);
  });
  
  Array.from(keymapBody2.querySelectorAll("tr")).forEach(row => {
    const rowData = [];
    Array.from(row.querySelectorAll("td")).forEach(cell => {
      const btnDiv = cell.querySelector("div.inner-btn");
      rowData.push({
        text: btnDiv ? btnDiv.textContent : cell.textContent,
        className: cell.className,
        btnClassName: btnDiv ? btnDiv.className : null,
        dataCmd: cell.dataset.cmd || null,
        dataCol: cell.dataset.col || null,
      });
    });
    data.keymapBody2.push(rowData);
  });
  
  Array.from(keymapBody3.querySelectorAll("tr")).forEach(row => {
    const rowData = [];
    Array.from(row.querySelectorAll("td")).forEach(cell => {
      const btnDiv = cell.querySelector("div.inner-btn");
      rowData.push({
        text: btnDiv ? btnDiv.textContent : cell.textContent,
        className: cell.className,
        btnClassName: btnDiv ? btnDiv.className : null,
        dataCmd: cell.dataset.cmd || null,
        dataCol: cell.dataset.col || null,
      });
    });
    data.keymapBody3.push(rowData);
  });
  
  localStorage.setItem("buttonState", JSON.stringify(data));
  console.log("Button state saved");
}

function restoreSelectedCell() {
  const savedData = localStorage.getItem("buttonState");
  if (!savedData) return;
  
  const data = JSON.parse(savedData);
  
  data.gameBody.forEach(rowData => {
    rowData.forEach(cellData => {
      const selector = `[data-cmd="${cellData.dataCmd}"][data-col="${cellData.dataCol}"]`;
      const cell = gameBody.querySelector(selector);
      if (!cell) return;
      
      cell.className = cellData.className;
      const btn = cell.querySelector("div.inner-btn");
      if (btn) {
        btn.className = cellData.btnClassName || "inner-btn";
        btn.textContent = cellData.text || "";
      } else if (cellData.text) {
        const newBtn = document.createElement("div");
        newBtn.className = cellData.btnClassName || "inner-btn";
        newBtn.textContent = cellData.text;
        cell.textContent = "";
        cell.appendChild(newBtn);
      } else {
        cell.textContent = cellData.text || "";
      }
    });
  });
  
  data.keymapBody2.forEach(rowData => {
    rowData.forEach(cellData => {
      const selector = `[data-cmd="${cellData.dataCmd}"][data-col="${cellData.dataCol}"]`;
      const cell = keymapBody2.querySelector(selector);
      if (!cell) return;
      
      cell.className = cellData.className;
      const btn = cell.querySelector("div.inner-btn");
      if (btn) {
        btn.className = cellData.btnClassName || "inner-btn";
        btn.textContent = cellData.text || "";
      } else if (cellData.text) {
        const newBtn = document.createElement("div");
        newBtn.className = cellData.btnClassName || "inner-btn";
        newBtn.textContent = cellData.text;
        cell.textContent = "";
        cell.appendChild(newBtn);
      } else {
        cell.textContent = cellData.text || "";
      }
    });
  });
  
  data.keymapBody3.forEach(rowData => {
    rowData.forEach(cellData => {
      const selector = `[data-cmd="${cellData.dataCmd}"][data-col="${cellData.dataCol}"]`;
      const cell = keymapBody3.querySelector(selector);
      if (!cell) return;
      
      cell.className = cellData.className;
      const btn = cell.querySelector("div.inner-btn");
      if (btn) {
        btn.className = cellData.btnClassName || "inner-btn";
        btn.textContent = cellData.text || "";
      } else if (cellData.text) {
        const newBtn = document.createElement("div");
        newBtn.className = cellData.btnClassName || "inner-btn";
        newBtn.textContent = cellData.text;
        cell.textContent = "";
        cell.appendChild(newBtn);
      } else {
        cell.textContent = cellData.text || "";
      }
    });
  });
  
  console.log("Button state restored");
}

function restoreButtonState() {
  const savedData = localStorage.getItem("buttonState");
  if (!savedData) return;
  
  const data = JSON.parse(savedData);
  
  data.gameBody.forEach(rowData => {
    rowData.forEach(cellData => {
      const selector = `[data-cmd="${cellData.dataCmd}"][data-col="${cellData.dataCol}"]`;
      const cell = gameBody.querySelector(selector);
      if (!cell) return;
      
      cell.className = cellData.className;
      const btn = cell.querySelector("div.inner-btn");
      if (btn) {
        btn.className = cellData.btnClassName || "inner-btn";
        btn.textContent = cellData.text || "";
      } else if (cellData.text) {
        // もしボタンがないなら新規作成して追加
        const newBtn = document.createElement("div");
        newBtn.className = cellData.btnClassName || "inner-btn";
        newBtn.textContent = cellData.text;
        cell.textContent = "";
        cell.appendChild(newBtn);
      } else {
        cell.textContent = cellData.text || "";
      }
    });
  });
  
  data.keymapBody2.forEach(rowData => {
    rowData.forEach(cellData => {
      const selector = `[data-cmd="${cellData.dataCmd}"][data-col="${cellData.dataCol}"]`;
      const cell = keymapBody2.querySelector(selector);
      if (!cell) return;
      
      cell.className = cellData.className;
      const btn = cell.querySelector("div.inner-btn");
      if (btn) {
        btn.className = cellData.btnClassName || "inner-btn";
        btn.textContent = cellData.text || "";
      } else if (cellData.text) {
        const newBtn = document.createElement("div");
        newBtn.className = cellData.btnClassName || "inner-btn";
        newBtn.textContent = cellData.text;
        cell.textContent = "";
        cell.appendChild(newBtn);
      } else {
        cell.textContent = cellData.text || "";
      }
    });
  });
  
  data.keymapBody3.forEach(rowData => {
    rowData.forEach(cellData => {
      const selector = `[data-cmd="${cellData.dataCmd}"][data-col="${cellData.dataCol}"]`;
      const cell = keymapBody3.querySelector(selector);
      if (!cell) return;
      
      cell.className = cellData.className;
      const btn = cell.querySelector("div.inner-btn");
      if (btn) {
        btn.className = cellData.btnClassName || "inner-btn";
        btn.textContent = cellData.text || "";
      } else if (cellData.text) {
        const newBtn = document.createElement("div");
        newBtn.className = cellData.btnClassName || "inner-btn";
        newBtn.textContent = cellData.text;
        cell.textContent = "";
        cell.appendChild(newBtn);
      } else {
        cell.textContent = cellData.text || "";
      }
    });
  });
  
  console.log("Button state restored");
}

function restoreButtonState() {
  const savedData = localStorage.getItem("buttonState");
  if (!savedData) return;
  
  const data = JSON.parse(savedData);
  
  function restoreBodyState(bodyData, bodyElement) {
    bodyData.forEach(rowData => {
      rowData.forEach(cellData => {
        const selector = `[data-cmd="${cellData.dataCmd}"][data-col="${cellData.dataCol}"]`;
        const cell = bodyElement.querySelector(selector);
        if (!cell) return;
        
        cell.className = cellData.className;
        
        const btn = cell.querySelector("div.inner-btn");
        if (btn) {
          btn.className = cellData.btnClassName || "inner-btn";
          btn.textContent = cellData.text || "";
        } else {
          cell.textContent = cellData.text || "";
        }
      });
    });
  }
  
  restoreBodyState(data.gameBody, gameBody0001);
  restoreBodyState(data.keymapBody2, keymapBody0002);
  restoreBodyState(data.keymapBody3, keymapBody0003);
  
  console.log("Button state restored");
}

window.addEventListener("orientationchange", restoreSelectedCell);
window.addEventListener("resize", restoreSelectedCell);
document.addEventListener("DOMContentLoaded", restoreSelectedCell);

function restoreButtonState() {
  const savedData = localStorage.getItem("buttonState");
  if (!savedData) return;
  
  const data = JSON.parse(savedData);
  
  // gameBody復元
  data.gameBody.forEach(rowData => {
    rowData.forEach(cellData => {
      // data-cmd と data-col で対象セルを特定
      const selector = `[data-cmd="${cellData.dataCmd}"][data-col="${cellData.dataCol}"]`;
      const cell = gameBody.querySelector(selector);
      if (!cell) return;
      
      cell.className = cellData.className;
      const btn = cell.querySelector("div.inner-btn");
      if (btn) {
        btn.className = cellData.btnClassName || "inner-btn";
        btn.textContent = cellData.text || "";
      } else {
        cell.textContent = cellData.text || "";
      }
    });
  });
  
  // keymapBody2復元 同様
  data.keymapBody2.forEach(rowData => {
    rowData.forEach(cellData => {
      const selector = `[data-cmd="${cellData.dataCmd}"][data-col="${cellData.dataCol}"]`;
      const cell = keymapBody2.querySelector(selector);
      if (!cell) return;
      
      cell.className = cellData.className;
      const btn = cell.querySelector("div.inner-btn");
      if (btn) {
        btn.className = cellData.btnClassName || "inner-btn";
        btn.textContent = cellData.text || "";
      } else {
        cell.textContent = cellData.text || "";
      }
    });
  });
  
  // keymapBody3復元 同様
  data.keymapBody3.forEach(rowData => {
    rowData.forEach(cellData => {
      const selector = `[data-cmd="${cellData.dataCmd}"][data-col="${cellData.dataCol}"]`;
      const cell = keymapBody3.querySelector(selector);
      if (!cell) return;
      
      cell.className = cellData.className;
      const btn = cell.querySelector("div.inner-btn");
      if (btn) {
        btn.className = cellData.btnClassName || "inner-btn";
        btn.textContent = cellData.text || "";
      } else {
        cell.textContent = cellData.text || "";
      }
    });
  });
  
  console.log("Button state restored");
}

window.addEventListener("orientationchange", restoreSelectedCell);
window.addEventListener("resize", restoreSelectedCell);
document.addEventListener("DOMContentLoaded", restoreSelectedCell);

function syncGame02ToKeymap01() {
  const gameRows = [...gameBody0001.querySelectorAll("tr")];
  const keymapRows = [...keymapBody0002.querySelectorAll("tr")];
  
  gameRows.forEach((gameRow, i) => {
    const gameCell = gameRow.cells[1]; // gameBody 2列目
    const keymapRow = keymapRows[i];
    const keymapCell = keymapRow?.cells[0]; // keymapBody 1列目のみを対象
    
    if (!gameCell || !keymapCell) return;
    
    // 対象の 1列目のみクリア（他の列には触れない）
    keymapCell.innerHTML = "";
    keymapCell.className = "";
    
    const btn = gameCell.querySelector(".inner-btn");
    if (!btn) return;
    
    const clonedBtn = btn.cloneNode(true);
    
    // gameCell のクラスに応じてスタイルを適用
    if (gameCell.classList.contains("fixed-cell")) {
      keymapCell.classList.add("fixed-cell", "fixed-cell-copy");
      clonedBtn.classList.add("shape-fixed");
    } else if (gameCell.classList.contains("dual")) {
      keymapCell.classList.add("dual", "fixed-cell-copy");
    } else {
      keymapCell.classList.add("fixed-cell-copy");
      clonedBtn.classList.add("shape-copy");
    }
    
    keymapCell.appendChild(clonedBtn);
  });
}

function createGameTable() {
  console.log("🧪 gameCommands:", gameCommands);
  console.log("createGameTable start");
  
  gameBody0001.innerHTML = "";
  
  gameCommands.forEach((cmd, index) => {
    console.log("createGameTable loop start:", index, cmd.name);
    const row = document.createElement("tr");
    row.dataset.index = index;
    
    const nameCell = document.createElement("td");
    nameCell.textContent = cmd.name;
    if (cmd.fixed !== undefined) {
      nameCell.classList.add("fixed-cell");
    }
    row.appendChild(nameCell);
    commandCellMap.set(cmd.name, []);
    
    for (let i = 0; i < NUM_BIND_CELLS; i++) {
      const cell = document.createElement("td");
      
      if (cmd.fixed !== undefined && cmd.fixed !== "") {
        const btn = document.createElement("div");
        btn.classList.add("inner-btn", "shape-fixed");
        btn.textContent = cmd.fixed;
        
        cell.classList.add("fixed-cell");
        cell.appendChild(btn);
      } else if (cmd.dual) {
        cell.classList.add("dual");
        const placeholderSpan = document.createElement("span");
        placeholderSpan.textContent = "…";
        cell.appendChild(placeholderSpan);
        cell.append(" + ");
        
        const dualBtn = document.createElement("div");
        dualBtn.classList.add("inner-btn", "shape-dual");
        dualBtn.textContent = "🕹L";
        cell.appendChild(dualBtn);
        commandCellMap.get(cmd.name).push(cell);
      } else {
        // game 側
        cell.classList.add("btn-cell5");
        
        let innerBtn = cell.querySelector(".inner-btn");
        if (!innerBtn) {
          innerBtn = document.createElement("div");
          innerBtn.classList.add("inner-btn");
          cell.appendChild(innerBtn);
        }
        
        // 中身が空なら「＋」をセット
        if (innerBtn.textContent.trim() === "") {
          innerBtn.textContent = "…";
        }
        
        cell.addEventListener("click", () => handleCellClick(cell, cmd.name, 0, false));
        commandCellMap.get(cmd.name).push(cell);
      }
      
      row.appendChild(cell);
    }
    
    gameBody0001.appendChild(row);
  });
  
  // ✅ テーブル要素名をすべて最新の整合性に合わせる
  enableRowDragAndDrop(gameBody0001, keymapBody0002, keymapBody0003);
  console.log("createGameTable end, total rows in gameBody0001:", gameBody0001.querySelectorAll("tr").length);
  console.log("createGameTable end");
}

function createKeymapTable(commands) {
  console.log("createKeymapTable start");
  console.log("🧪 keymapCommands:", keymapCommands);
  /*
  keymapCellMap.clear();
  */
  keymapBody2.innerHTML = "";
  keymapBody3.innerHTML = "";
  
  commands.forEach((cmdObj, i) => {
    const cmdName = cmdObj.name;
    const row2 = document.createElement("tr");
    const row3 = document.createElement("tr");
    
    for (let col = 0; col < 4; col++) {
      // 🔽 各テーブルに必要な列のみ処理
      const includeIn2 = col === 0 || col === 1;
      const includeIn3 = col === 2 || col === 3;
      
      if (includeIn2) {
        const cell2 = document.createElement("td");
        if (col === 3) {
          if (cmdName.length > 0) {
            const container2 = document.createElement("div");
            container2.className = "scrolling-box-container";
            const box2 = document.createElement("div");
            box2.className = "scrolling-box";
            box2.textContent = cmdName;
            container2.appendChild(box2);
            cell2.appendChild(container2);
          } else {
            cell2.textContent = cmdName;
          }
          cell2.className = "label-cell";
        } else {
          cell2.className = `btn-cell6 btn-cell6-0${col + 1}`;
          cell2.addEventListener("click", () => handleCellClick(cell2, cmdName, col, true));
          const key = `${cmdName}_${col}`;
          if (!keymapCellMap.has(key)) keymapCellMap.set(key, []);
          keymapCellMap.get(key).push(cell2);
        }
        row2.appendChild(cell2);
      }
      
      if (includeIn3) {
        const cell3 = document.createElement("td");
        if (col === 3) {
          if (cmdName.length > 0) {
            const container3 = document.createElement("div");
            container3.className = "scrolling-box-container";
            const box3 = document.createElement("div");
            box3.className = "scrolling-box";
            box3.textContent = cmdName;
            container3.appendChild(box3);
            cell3.appendChild(container3);
          } else {
            cell3.textContent = cmdName;
          }
          cell3.className = "label-cell";
        } else {
          cell3.className = `btn-cell6 btn-cell6-0${col + 1}`;
          cell3.addEventListener("click", () => handleCellClick(cell3, cmdName, col, true));
          const key = `${cmdName}_${col}`;
          if (!keymapCellMap.has(key)) keymapCellMap.set(key, []);
          keymapCellMap.get(key).push(cell3);
        }
        row3.appendChild(cell3);
      }
    }
    
    keymapBody2.appendChild(row2);
    keymapBody3.appendChild(row3);
  });
  
  console.log("createKeymapTable end");
}

function syncRowOrdersBetweenTables() {
  const gameRows = [...gameBody0001.querySelectorAll("tr")];
  const keymapRows2 = [...keymapBody0002.querySelectorAll("tr")];
  const keymapRows3 = [...keymapBody0003.querySelectorAll("tr")];
  
  // キーマップ2の行をゲームテーブル順に並び替え
  gameRows.forEach((gameRow, i) => {
    const correspondingRow2 = keymapRows2[i];
    if (correspondingRow2) {
      keymapBody0002.appendChild(correspondingRow2);
    }
  });
  
  // キーマップ3の行も同様に並び替え
  gameRows.forEach((gameRow, i) => {
    const correspondingRow3 = keymapRows3[i];
    if (correspondingRow3) {
      keymapBody0003.appendChild(correspondingRow3);
    }
  });
}
/*
function updateKeymapCell() {
  keymapCell.innerHTML = gameCell.innerHTML;
}
*/
function enableRowDragAndDrop(primaryBody, syncedBody) {
  let draggingRow = null;
  
  primaryBody.querySelectorAll("tr").forEach((row) => {
    row.setAttribute("draggable", true);
    
    row.addEventListener("dragstart", () => {
      draggingRow = row;
      row.classList.add("dragging");
      
      const index = [...primaryBody.children].indexOf(row);
      const syncedRow = syncedBody.children[index];
      if (syncedRow) syncedRow.classList.add("dragging");
    });
    
    row.addEventListener("dragend", () => {
      syncRowOrdersBetweenTables()
      const index = [...primaryBody.children].indexOf(draggingRow);
      const syncedRow = syncedBody.querySelector(".dragging");
      
      if (syncedRow) syncedRow.classList.remove("dragging");
      if (draggingRow) draggingRow.classList.remove("dragging");
      
      draggingRow = null;
    });
    
  });
  
  primaryBody.addEventListener("dragover", (e) => {
    e.preventDefault();
    const dragging = primaryBody.querySelector(".dragging");
    if (!dragging) return;
    
    const after = Array.from(primaryBody.children).find((child) => {
      const rect = child.getBoundingClientRect();
      return e.clientY < rect.top + rect.height / 2;
    });
    
    const draggingIndex = [...primaryBody.children].indexOf(dragging);
    
    if (!after) {
      primaryBody.appendChild(dragging);
      syncedBody.appendChild(syncedBody.children[draggingIndex]);
    } else {
      const afterIndex = [...primaryBody.children].indexOf(after);
      primaryBody.insertBefore(dragging, after);
      syncedBody.insertBefore(syncedBody.children[draggingIndex], syncedBody.children[afterIndex]);
    }
  });
}

function alignPopup(containerRef, popupRef) {
  const rect = containerRef.getBoundingClientRect();
  
  console.log('alignPopup to:',
    containerRef.id,
    rect); // ← ここを追加
  
  popupRef.style.top = rect.top + window.scrollY + "px";
  popupRef.style.left = rect.left + window.scrollX + "px";
  popupRef.style.width = rect.width + "px";
  popupRef.style.height = rect.height + "px";
}

function closePoolWindow5() {
  poolWindow0005.classList.remove("show");
}

function closePoolWindow2() {
  poolWindow0002.classList.remove("show");
}

function closePoolWindow3() {
  poolWindow0003.classList.remove("show");
}

function handleCellClick(cell, cmd, colIndex = 0, isKeymap = false) {
  console.log("handleCellClick called:", cell, cmd, colIndex);
  
  // もしセルが null や undefined の場合（プール外をクリックした時やハイライト解除用に呼ばれた時）、
  // 選択状態を解除して終了
  if (!cell) {
    if (selectedCell) {
      selectedCell.classList.remove("highlight");
      selectedCell = null;
      selectedCommand = null;
      selectedColIndex = null;
      selectedCellClass = null;
    }
    return;
  }
  
  if (selectedCell === cell) {
    selectedCell.classList.remove("highlight");
    selectedCell = null;
    selectedCommand = null;
    selectedColIndex = null;
    selectedCellClass = null;
    return;
  }
  
  if (selectedCell) {
    const oldVal = selectedCell.textContent;
    const newVal = cell.textContent;
    
    console.log("🔧 updateCommandCells selected:", selectedCommand, newVal, selectedColIndex, isKeymap);
    console.log("🔧 updateCommandCells current :", cmd, oldVal, colIndex, isKeymap);
    
    updateCommandCells(selectedCommand, newVal, selectedColIndex, isKeymap);
    updateCommandCells(cmd, oldVal, colIndex, isKeymap);
    
    // ここでボタン配置完了 → ハイライト解除・選択解除も行う
    selectedCell.classList.remove("highlight");
    selectedCell = null;
    selectedCommand = null;
    selectedColIndex = null;
    selectedCellClass = null;
    
    return;
  }
  
  // ここからは選択セルがまだなかった場合の処理。選択・ハイライト付ける
  selectedCell = cell;
  selectedCommand = cmd;
  selectedColIndex = colIndex;
  
  selectedCellClass = Array.from(cell.classList).find(cls =>
    cls.startsWith("btn-cell6-") || cls === "btn-cell5"
  );
  
  cell.classList.add("highlight");
  
  if (cell.classList.contains("btn-cell5")) {
    poolWindow0002.classList.remove("show");
    poolWindow0003.classList.remove("show");
    container1.style.zIndex = 99;
    container2.style.zIndex = 97;
    container3.style.zIndex = 95;
    container4.style.zIndex = 1;
    alignPopup(container4, poolWindow5);
    poolWindow0005.classList.add("show");
  } else if (cell.classList.contains("btn-cell6-02")) {
    poolWindow0003.classList.remove("show");
    poolWindow0005.classList.remove("show");
    container1.style.zIndex = 99;
    container2.style.zIndex = 97;
    container3.style.zIndex = 95;
    container4.style.zIndex = 1;
    alignPopup(container4, poolWindow2);
    poolWindow0002.classList.add("show");
  } else if (cell.classList.contains("btn-cell6-03")) {
    poolWindow0002.classList.remove("show");
    poolWindow0005.classList.remove("show");
    container1.style.zIndex = 99;
    container2.style.zIndex = 97;
    container3.style.zIndex = 95;
    container4.style.zIndex = 1;
    alignPopup(container4, poolWindow3);
    poolWindow0003.classList.add("show");
  }
}
/*
function handleCellClick(cell, cmd, colIndex = 0, isKeymap = false) {
  console.log("handleCellClick called:", cell, cmd, colIndex);
  
  if (selectedCell === cell) {
    selectedCell.classList.remove("highlight");
    selectedCell = null;
    selectedCommand = null;
    selectedColIndex = null;
    selectedIsKeymap = false;
    selectedCellClass = null;
    return;
  }
  
  if (selectedCell) {
    const oldVal = selectedCell.textContent;
    const newVal = cell.textContent;
    
    console.log("🔧 updateCommandCells selected:", selectedCommand, newVal, selectedColIndex, isKeymap);
    console.log("🔧 updateCommandCells current :", cmd, oldVal, colIndex, isKeymap);
    
    updateCommandCells(selectedCommand, newVal, selectedColIndex, isKeymap);
    updateCommandCells(cmd, oldVal, colIndex, isKeymap);
    
    selectedCell.classList.remove("highlight");
    selectedCell = null;
    selectedCommand = null;
    selectedColIndex = null;
    selectedCellClass = null;
    return;
  }
  
  selectedCell = cell;
  selectedCommand = cmd;
  selectedColIndex = colIndex;
  
  // クラス名記録（btn-cell6-02 / btn-cell6-03 など）
  selectedCellClass = Array.from(cell.classList).find(cls =>
    cls.startsWith("btn-cell6-") || cls === "btn-cell5"
  );
  
  cell.classList.add("highlight");
  
  // ウィンドウ表示処理
  if (cell.classList.contains("btn-cell5")) {
    // ゲーム用ボタンウィンドウ表示
    poolWindow0002.classList.remove("show");
    poolWindow0003.classList.remove("show");
    container1.style.zIndex = 99;
    container2.style.zIndex = 97;
    container3.style.zIndex = 95;
    container4.style.zIndex = 1;
    alignPopup(container4, poolWindow5);
    poolWindow0005.classList.add("show");
    
  } else if (cell.classList.contains("btn-cell6-02")) {
    // キーマップ2用ボタンウィンドウ表示
    poolWindow0003.classList.remove("show");
    poolWindow0005.classList.remove("show");
    container1.style.zIndex = 99;
    container2.style.zIndex = 97;
    container3.style.zIndex = 95;
    container4.style.zIndex = 1;
    alignPopup(container4, poolWindow2);
    poolWindow0002.classList.add("show");
    
  } else if (cell.classList.contains("btn-cell6-03")) {
    // キーマップ3用ボタンウィンドウ表示
    poolWindow0002.classList.remove("show");
    poolWindow0005.classList.remove("show");
    container1.style.zIndex = 99;
    container2.style.zIndex = 97;
    container3.style.zIndex = 95;
    container4.style.zIndex = 1;
    alignPopup(container4, poolWindow3);
    poolWindow0003.classList.add("show");
  }
}
*/
function updateCommandCells(cmd, val, colIndex = 0, cellClass = "btn-cell5") {
  console.log("🔧 updateCommandCells called with:", cmd, val, colIndex, cellClass);
  
  let isBtn = false;
  
  if (cellClass === "btn-cell5") {
    isBtn = gameBtnPool.includes(val);
  } else if (cellClass === "btn-cell6-02") {
    isBtn = btnKeymapPool2.includes(val);
  } else if (cellClass === "btn-cell6-03") {
    isBtn = btnKeymapPool3.includes(val);
  }
  
  const createBtnEl = (value) => {
    const original = getOriginalLabel(value);
    const shapeClass = getBtnShapeClass(original);
    const colorClass = "btn-" + original;
    const label = labelMaps[currentMode]?.[original] ?? original;
    
    const wrapper = document.createElement("div");
    wrapper.style.position = "relative";
    wrapper.style.width = "100%";
    wrapper.style.height = "100%";
    
    const btnEl = document.createElement("div");
    btnEl.className = `inner-btn ${shapeClass} ${colorClass}`;
    btnEl.textContent = label;
    btnEl.dataset.original = original;
    
    wrapper.appendChild(btnEl);
    return wrapper;
  };
  
  // ▼ 直接選択されたセルだけを更新（selectedCell が対象）
  if (selectedCell && selectedCell.classList.contains(cellClass)) {
    selectedCell.innerHTML = "";
    if (isBtn) {
      selectedCell.appendChild(createBtnEl(val));
    } else {
      selectedCell.textContent = val;
    }
    return;
  }
  
  // ▼ keymap2 or keymap3 側
  if (cellClass === "btn-cell6-02" || cellClass === "btn-cell6-03") {
    const key = `${cmd}_${colIndex}`;
    if (!keymapCellMap.has(key)) return;
    
    keymapCellMap.get(key).forEach((c) => {
      c.innerHTML = "";
      if (isBtn) {
        c.appendChild(createBtnEl(val));
      } else {
        c.textContent = val;
      }
    });
    return;
  }
  
  // ▼ game 側（btn-cell5）
  if (!commandCellMap.has(cmd)) return;
  
  commandCellMap.get(cmd).forEach((c) => {
    c.innerHTML = "";
    if (isBtn) {
      c.appendChild(createBtnEl(val));
    } else {
      c.textContent = val;
    }
  });
  
  // ▼ 特別処理
  if (cmd === "AIM") {
    aimButton = val;
    updateLeanBinds();
  }
  
  if (cmd === "RELOAD" || cmd === "INTERACT") {
    const groupVal = val;
    ["RELOAD", "INTERACT"].forEach((key) => {
      if (!commandCellMap.has(key)) return;
      commandCellMap.get(key).forEach((c) => {
        c.innerHTML = "";
        if (isBtn) {
          c.appendChild(createBtnEl(groupVal));
        } else {
          c.textContent = groupVal;
        }
      });
    });
  }
}
/*
function updateCommandCells(cmd, val, colIndex = 0, isKeymap = false) {
  console.log("🔧 updateCommandCells called with:", cmd, val, colIndex, isKeymap);
  
  const isBtn = btnKeymapPool2.includes(val) || btnKeymapPool3.includes(val) || btnGamePool.includes(val);
  
  const createBtnEl = (value) => {
    const original = getOriginalLabel(value);
    const shapeClass = getBtnShapeClass(original);
    const colorClass = "btn-" + original;
    const label = labelMaps[currentMode]?.[original] ?? original;
    
    const wrapper = document.createElement("div");
    wrapper.style.position = "relative";
    wrapper.style.width = "100%";
    wrapper.style.height = "100%";
    
    const btnEl = document.createElement("div");
    btnEl.className = `inner-btn ${shapeClass} ${colorClass}`;
    btnEl.textContent = label;
    btnEl.dataset.original = original;
    
    wrapper.appendChild(btnEl);
    return wrapper;
  };
  
  // ✅ selectedCellClass に応じて selectedCell にのみ反映
  if (typeof selectedCellClass === "string" && selectedCell && selectedCell.classList.contains(selectedCellClass)
  ) {
    let oldVal = null;
    const existingBtn = selectedCell.querySelector(".inner-btn");
    if (existingBtn) {
      oldVal = existingBtn.dataset.original || getOriginalLabel(existingBtn.textContent.trim());
    } else {
      oldVal = getOriginalLabel(selectedCell.textContent.trim());
    }
    
    selectedCell.innerHTML = "";
    if (isBtn) {
      selectedCell.appendChild(createBtnEl(val));
    } else {
      selectedCell.textContent = val;
    }
    
    // ▼ selectedCellClass に応じて正しいマスターデータを参照
    let bodyList, currentBodyList, PoolList, currentPoolList, type;
    
    if (selectedCellClass === "btn-cell5") {
      bodyList = gameBody0001;
      currentBodyList = gameBody0001Current;
      PoolList = btnGamePool0001;
      currentPoolList = btnGamePool0001Current;
      type = "game";
      
    } else if (selectedCellClass === "btn-cell6-02") {
      bodyList = keymapBody0002;
      currentBodyList = keymapBody0002Current;
      PoolList = btnKeymapPool0002;
      currentPoolList = btnKeymapPool0002Current;
      type = "keymap2";
      
    } else if (selectedCellClass === "btn-cell6-03") {
      bodyList = keymapBody0003;
      currentBodyList = keymapBody0003Current;
      PoolList = btnKeymapPool0003;
      currentPoolList = btnKeymapPool0003Current;
      type = "keymap3";
    }
    
    if (PoolList && currentPoolList) {
      const idx = currentPoolList.indexOf(val);
      if (idx !== -1) currentPoolList.splice(idx, 1);
      
      if (oldVal && !currentPoolList.includes(oldVal)) {
        currentPoolList.push(oldVal);
      }
      
      // ▼ rebuildBtnPool 呼び出し（DOM もマスターデータに合わせる）
      if (type === "game") {
        rebuildBtnPool(btnGamePool, gameBody0001Current, document.getElementById("btnGamePool"), "game");
      } else if (type === "keymap2") {
        rebuildBtnPool(btnKeymapPool2, keymapBody0002Current, document.getElementById("btnKeymapPool2"), "keymap2");
      } else if (type === "keymap3") {
        rebuildBtnPool(btnKeymapPool3, keymapBody0003Current, document.getElementById("btnKeymapPool3"), "keymap3");
      }
    }
    
    return;
  }
  
  // ▼ keymap 側（複数セルに反映）
  if (isKeymap) {
    const key = `${cmd}_${colIndex}`;
    const cells = keymapCellMap.get(key);
    if (!cells) return;
    
    cells.forEach((c) => {
      c.innerHTML = "";
      if (isBtn) {
        c.appendChild(createBtnEl(val));
      } else {
        c.textContent = val;
      }
    });
    
    return;
  }
  
  // ▼ game 側（複数セルに反映）
  if (!commandCellMap.has(cmd)) return;
  
  commandCellMap.get(cmd).forEach((c) => {
    c.innerHTML = "";
    if (isBtn) {
      c.appendChild(createBtnEl(val));
    } else {
      c.textContent = val;
    }
  });
  
  // ▼ 特別処理
  if (cmd === "AIM") {
    selectedAimBtn = val;
    updateLeanBinds();
  }
  
  if (cmd === "RELOAD" || cmd === "INTERACT") {
    const groupVal = val;
    ["RELOAD", "INTERACT"].forEach((key) => {
      if (!commandCellMap.has(key)) return;
      commandCellMap.get(key).forEach((c) => {
        c.innerHTML = "";
        if (isBtn) {
          c.appendChild(createBtnEl(groupVal));
        } else {
          c.textContent = groupVal;
        }
      });
    });
  }
}
*/
function updateLeanBinds() {
  const cells = commandCellMap.get("LEAN L/R");
  if (!cells) return;
  
  // AIMボタン取得
  const aimCell = commandCellMap.get("AIM")?.[0];
  let aimBtnClone = null;
  
  if (aimCell) {
    const originalBtn = aimCell.querySelector(".inner-btn");
    if (originalBtn) {
      aimBtnClone = originalBtn.cloneNode(true); // ◉ のスタイルをそのままコピー
    }
  }
  
  cells.forEach((cell) => {
    // 既存の内容をクリア
    cell.textContent = "";
    
    if (aimBtnClone) {
      cell.appendChild(aimBtnClone.cloneNode(true)); // ◉のクローンを挿入
    } else {
      cell.append("…");
    }
    
    // + をテキストで追加
    cell.append(" + ");
    
    // 🕹Lボタンを新たに作成
    const dualBtn = document.createElement("div");
    dualBtn.className = "inner-btn shape-dual";
    dualBtn.textContent = "🕹L";
    
    cell.appendChild(dualBtn);
  });
}

function getBtnShapeClass(btn) {
  if (roundBtn.includes(btn)) return "shape-round";
  if (oblongBtn.includes(btn)) return "shape-oblong";
  if (squareBtn.includes(btn)) return "shape-square";
  if (joystickBtn.includes(btn)) return "shape-joystick";
  if (macroBtn.includes(btn)) return "shape-macro";
  return "shape-square";
}

function getOriginalLabel(label) {
  for (const mode in labelMaps) {
    for (const key in labelMaps[mode]) {
      if (labelMaps[mode][key] === label) return key;
    }
  }
  return label; // fallback
}

function updateButtonLabels(mode) {
  const btns = document.querySelectorAll(".inner-btn");
  
  btns.forEach((btn) => {
    let original = btn.dataset.original;
    
    // 初回のみ保存
    if (!original) {
      original = getOriginalLabel(btn.textContent.trim());
      btn.dataset.original = original;
    }
    
    const mapped = labelMaps[mode]?.[original];
    btn.textContent = mapped ?? original;
  });
}

function setMode(mode) {
  currentMode = mode;
  document.body.className = `mode-${mode}`;
  updateButtonLabels(mode);
  updateCommandCellLabels(); // ラベルだけ更新
  
  // 🔧 各セルのボタンも再生成する
  gameCommands.forEach((cmd, i) => {
    const val = cmd.value;
    updateCommandCells(cmd, val, 0, "game");
  });
  keymapCommands.forEach((cmd, i) => {
    const val = cmd.value2;
    updateCommandCells(cmd, val, 1, "keymap2");
    updateCommandCells(cmd, cmd.value3, 2, "keymap3");
  });
}

function updateCommandCellLabels() {
  for (const list of commandCellMap.values()) {
    list.forEach((cell) => {
      const btn = cell.querySelector(".inner-btn");
      if (!btn || !btn.dataset.original) return;
      const original = btn.dataset.original;
      btn.textContent = labelMaps[currentMode]?.[original] ?? original;
    });
  }
}

function rebuildBtnPool(master, current, tbody, type, bodyElement) {
  if (!tbody) {
    console.error("rebuildBtnPool: tbody is null or undefined");
    return;
  }
  
  if (bodyElement) {
    // ボディ内のボタン名を取得
    const bodyButtons = Array.from(bodyElement.querySelectorAll(".inner-btn"))
      .map(el => el.textContent.trim());
    
    // 重複排除
    const uniqueBodyButtons = [...new Set(bodyButtons)];
    
    // current を master - bodyButtons で作り直す
    current.length = 0;
    for (const btn of master) {
      if (!uniqueBodyButtons.includes(btn)) {
        current.push(btn);
      }
    }
    
    // 念のため、current の中で master に存在しないものは削除
    for (let i = current.length - 1; i >= 0; i--) {
      if (!master.includes(current[i])) {
        current.splice(i, 1);
      }
    }
  }
  
  // tbody をクリア
  tbody.innerHTML = "";
  
  // ボタン数がゼロなら終了
  if (current.length === 0) return;
  
  // 4列で行を作る
  for (let i = 0; i < current.length; i += 4) {
    const row = document.createElement("tr");
    
    for (let j = 0; j < 4; j++) {
      const idx = i + j;
      if (idx >= current.length) continue;
      
      const btn = current[idx];
      const cell = document.createElement("td");
      cell.className = "btn";
      
      const shapeClass = getBtnShapeClass(btn) || "";
      const colorClass = "btn-" + btn;
      
      const innerBtn = document.createElement("div");
      innerBtn.className = `inner-btn ${shapeClass} ${colorClass}`;
      innerBtn.textContent = btn;
      
      if (btn === "⬡") {
        innerBtn.style.opacity = "1.0";
        cell.classList.add("fixed-cell");
      } else {
        innerBtn.style.opacity = "0.9";
        cell.addEventListener("click", () => {
  if (!selectedCell) {
    // 選択セルがないなら何もしない（プールセルクリックだけなら）
    return;
  }
  
  // ここまで来るということは必ず selectedCell があり、かつハイライトもあるはず
  
  const innerBtn = cell.querySelector(".inner-btn");
  if (!innerBtn) return;
  
  const className = Array.from(selectedCell.classList).find(cls =>
    cls === "btn-cell5" || cls === "btn-cell6-02" || cls === "btn-cell6-03"
  );
  if (!className) return;
  
  // 旧ボタンをプールに戻す
  const oldEl = selectedCell.querySelector(".inner-btn");
  const oldVal = oldEl ? oldEl.textContent.trim() : selectedCell.textContent.trim();
  if (oldVal && !current.includes(oldVal)) {
    current.push(oldVal);
  }
  
  const btn = innerBtn.textContent.trim();
  
  // currentから移動したボタンを削除
  const index = current.indexOf(btn);
  if (index > -1) current.splice(index, 1);
  
  // プールのボタンを selectedCell に移動
  selectedCell.innerHTML = "";
  selectedCell.appendChild(innerBtn);
  
  updateCommandCells(selectedCommand, btn, selectedColIndex, className);
  
  // プールとボディの再描画
  rebuildBtnPool(btnGamePool, gameBody0001Current,
    document.getElementById("btnGamePool"), "game",
    document.getElementById("gameBody0001"));
  rebuildBtnPool(btnKeymapPool2, keymapBody0002Current,
    document.getElementById("btnKeymapPool2"), "keymap2",
    document.getElementById("keymapBody0002"));
  rebuildBtnPool(btnKeymapPool3, keymapBody0003Current,
    document.getElementById("btnKeymapPool3"), "keymap3",
    document.getElementById("keymapBody0003"));
  
  // 配置後はハイライトも選択も解除
  selectedCell.classList.remove("highlight");
console.log("Highlight removed from", selectedCell);
selectedCell = null;
selectedCommand = null;
selectedColIndex = null;
selectedCellClass = null;
});
      }
      
      cell.appendChild(innerBtn);
      row.appendChild(cell);
    }
    
    tbody.appendChild(row);
  }
}
document.querySelectorAll("#container1 .btn-cell5").forEach(cell => {
  cell.addEventListener("click", () => handleCellClick(cell, cell));
});

document.querySelectorAll("#container2 .btn-cell6-02").forEach(cell => {
  cell.addEventListener("click", () => handleCellClick(cell, cell));
});

document.querySelectorAll("#container3 .btn-cell6-03").forEach(cell => {
  cell.addEventListener("click", () => handleCellClick(cell, cell));
});

document.addEventListener("DOMContentLoaded", () => {
  createGameTable();
  createKeymapTable(keymapCommands);
  
  // 初期化時は current に master をコピー
  gameBody0001Current.length = 0;
  gameBody0001Current.push(...btnGamePool);
  
  keymapBody0002Current.length = 0;
  keymapBody0002Current.push(...btnKeymapPool2);
  
  keymapBody0003Current.length = 0;
  keymapBody0003Current.push(...btnKeymapPool3);
  
  // ここで初めて rebuild
  rebuildBtnPool(btnGamePool, gameBody0001Current,
    document.getElementById("btnGamePool"), "game",
    document.getElementById("gameBody0001"));
  
  rebuildBtnPool(btnKeymapPool2, keymapBody0002Current,
    document.getElementById("btnKeymapPool2"), "keymap2",
    document.getElementById("keymapBody0002"));
  
  rebuildBtnPool(btnKeymapPool3, keymapBody0003Current,
    document.getElementById("btnKeymapPool3"), "keymap3",
    document.getElementById("keymapBody0003"));
  
  closePoolWindow5();
  closePoolWindow2();
  closePoolWindow3();
  
  syncGame02ToKeymap01();
});