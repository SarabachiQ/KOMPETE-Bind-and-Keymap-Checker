// script32.js

function debugLog(msg) {
  const log = document.getElementById("log"); if (!log) return; const p = document.createElement("div"); p.textContent = msg; log.appendChild(p); log.scrollTop = log.scrollHeight;
}

const NUM_BIND_CELLS = 1;

const DUAL_PLACEHOLDER = "… + 🕹L";

const gameCommands = [ {
  name: "MOVE F/B/L/R",
  fixed: "🕹L"
}, {
  name: "FIRE🔥"
}, {
  name: "AIM"
}, {
  name: "MELEE"
}, {
  name: "RELOAD"
}, {
  name: "INTERACT"
}, {
  name: "CROUCH/SLIDE"
}, {
  name: "SPRINT"
}, {
  name: "JUMP/EXOSUIT (HOLD)"
}, {
  name: "EXOSUIT"
}, {
  name: "SWITCH WEAPON 1"
}, {
  name: "SWITCH WEAPON 2",
  fixed: ""
}, {
  name: "EQUIP MELEE WEAPON",
  fixed: "LB"
}, {
  name: "EQUIP UTILITY 1",
  fixed: "RB"
}, {
  name: "EQUIP UTILITY 2",
  fixed: "RB"
}, {
  name: "EQUIP KAPSULE",
  fixed: "LB+RB"
}, {
  name: "LEAN L/R",
  dual: true
}, {
  name: "DROP ITEM"
}, {
  name: "PING"
}, {
  name: "SWITCH SHOULDER"
}, {
  name: "TOGGLE SCORECARD"
}, {
  name: "EMOTE WHEEL"
}];

// 現在の表示モード（初期値は Xbox）
let currentMode = "xbox";

const labelMaps = {
  xbox: {
    X: "X",
    Y: "Y",
    A: "A",
    B: "B",
    LB: "LB",
    RB: "RB",
    LT: "LT",
    RT: "RT",
    L3: "L3",
    R3: "R3",
    M1: "M1",
    M2: "M2",
    M3: "M3",
    M4: "M4",
    "⬆": "⬆",
    "⬇": "⬇",
    "⬅": "⬅",
    "➡": "➡"
  },
  ps: {
    X: "✕",
    Y: "△",
    A: "〇",
    B: "□",
    LB: "L1",
    RB: "R1",
    LT: "L2",
    RT: "R2",
    L3: "L3",
    R3: "R3",
    M1: "M1",
    M2: "M2",
    M3: "M3",
    M4: "M4",
    "⬆": "↑",
    "⬇": "↓",
    "⬅": "←",
    "➡": "→"
  },
  switch: {
    X: "XX",
    Y: "YY",
    A: "AA",
    B: "BB",
    LB: "L",
    RB: "R",
    LT: "ZL",
    RT: "ZR",
    L3: "L3",
    R3: "R3",
    M1: "M1",
    M2: "M2",
    M3: "M3",
    M4: "M4",
    "⬆": "↑",
    "⬇": "↓",
    "⬅": "←",
    "➡": "→"
  }
};

// ボタンの形状
const roundBtn = ["X", "Y", "A", "B", "❐", "≡", "📷", "⬡"];
const oblongBtn = ["LB", "LT", "RB", "RT", "L3", "R3"];
const squareBtn = ["⬆", "⬇", "⬅", "➡"];
const macroBtn = ["M1", "M2", "M3", "M4"];

// 各ボタンの使用先プール
const gameBtnPool = [
  "X", "Y", "A", "B", "⬆", "⬇", "⬅", "➡",
  "LB", "RB", "LT", "RT", "L3", "R3",
  "❐", "≡", "📷", "⬡",
  "L🕹↑", "L🕹↓", "L🕹←", "L🕹→"
];

const keymapBtnPool = [
  "X", "Y", "A", "B", "⬆", "⬇", "⬅", "➡",
  "LB", "RB", "LT", "RT", "L3", "R3",
  "❐", "≡", "📷", "⬡", "M1", "M2", "M3", "M4"
];

const gameBody = document.getElementById("gameBody");
const keymapBody = document.getElementById("keymapBody");
const btnGameBody = document.getElementById("btnGameBody");
const btnKeymapBody = document.getElementById("btnKeymapBody");

let selectedCell = null; let selectedCommand = null; let aimButton = ""; let currentGamePool = [...gameBtnPool]; let currentKeymapPool = [...keymapBtnPool];

const commandCellMap = new Map();

function createGameTable() {
  gameCommands.forEach((cmd) => {
    const row = document.createElement("tr"); row.setAttribute("draggable", true);

    row.addEventListener("dragstart", (e) => {
      e.dataTransfer.setData("text/plain", JSON.stringify(cmd));
      e.dataTransfer.effectAllowed = "move";
      row.classList.add("dragging");
    });

    row.addEventListener("dragend", () => row.classList.remove("dragging"));

    row.addEventListener("dragover", (e) => {
      e.preventDefault();
      const dragging = document.querySelector(".dragging");
      if (dragging && dragging !== row) {
        const isBelow = dragging.compareDocumentPosition(row) & Node.DOCUMENT_POSITION_FOLLOWING;
        const target = isBelow ? row: row.previousSibling;
        row.parentNode.insertBefore(dragging, target?.nextSibling || row);
      }
    });

    const nameCell = document.createElement("td");
    nameCell.textContent = cmd.name;
    if (cmd.fixed !== undefined) {
      nameCell.classList.add("fixed-cell");
    }
    row.appendChild(nameCell);
    commandCellMap.set(cmd.name,
      []);

    // マウス操作でもタッチ操作でも、どのセルでもドラッグできるようにする
    row.addEventListener("pointerdown",
      () => {
        row.draggable = true;
      });

    for (let i = 0; i < NUM_BIND_CELLS; i++) {
      const cell = document.createElement("td");
      if (cmd.fixed !== undefined) {
        cell.textContent = cmd.fixed;
        cell.classList.add("fixed-cell");
      } else if (cmd.dual) {
        cell.textContent = DUAL_PLACEHOLDER;
        cell.classList.add("dual");
        commandCellMap.get(cmd.name).push(cell);
      } else {
        cell.addEventListener("click", () => handleCellClick(cell, cmd.name));
        cell.classList.add("btn-cell5");
        commandCellMap.get(cmd.name).push(cell);
      }
      row.appendChild(cell);
    }
    gameBody.appendChild(row);

  });
}

// --- ⑤ 各種 DOM・表示処理 ---
const container1 = document.getElementById("container1");
const container2 = document.getElementById("container2");
const poolWindow5 = document.getElementById("container5");
const poolWindow6 = document.getElementById("container6");

// ここにクリックイベント登録をまとめて書く
document.querySelectorAll("#container1 .btn-cell5").forEach(cell => {
  cell.addEventListener("click", () => handleCellClick(cell, cell));
});

document.querySelectorAll("#container2 .btn-cell6").forEach(cell => {
  cell.addEventListener("click", () => handleCellClick(cell, cell));
});

function alignPopup(containerRef, popupRef) {
  const rect = containerRef.getBoundingClientRect();
  
  console.log('alignPopup to:',
    containerRef.id, rect); // ← ここを追加
  
  popupRef.style.top = rect.top + window.scrollY + "px";
  popupRef.style.left = rect.left + window.scrollX + "px";
  popupRef.style.width = rect.width + "px";
  popupRef.style.height = rect.height + "px";
}

function closePoolWindow5() {
  const popup = document.getElementById("containerPopup5");
  if (popup) popup.classList.remove("show");
}

function closePoolWindow6() {
  const popup = document.getElementById("containerPopup6");
  if (popup) popup.classList.remove("show");
}

document.addEventListener("DOMContentLoaded", () => {
  const container1 = document.getElementById("container1");
  const container2 = document.getElementById("container2");
  const container3 = document.getElementById("container3");
  const poolWindow5 = document.getElementById("containerPopup5");
  const poolWindow6 = document.getElementById("containerPopup6");

  document.addEventListener("click", (event) => {
    const cell = event.target.closest(".btn-cell5, .btn-cell6");
    if (!cell) return;

    if (cell.classList.contains("btn-cell5")) {
      console.log(">> btn-cell5 clicked. Show PoolWindow5.");
      poolWindow6.classList.remove("show");
      container2.style.zIndex = 97;
      container1.style.zIndex = 99;
      alignPopup(container3, poolWindow5);
    }

    if (cell.classList.contains("btn-cell6")) {
      console.log(">> btn-cell6 clicked. Show PoolWindow6.");
      poolWindow5.classList.remove("show");
      container1.style.zIndex = 97;
      container2.style.zIndex = 99;
      alignPopup(container3, poolWindow6);
    }
  });
});

function handleCellClick(cell, cmd) {
  console.log("handleCellClick called:",
    cell,
    cmd);
  console.log("cell.classList:",
    cell.classList); // ★← 追加

  if (selectedCell === cell) {
    selectedCell.classList.remove("highlight");
    selectedCell = null;
    selectedCommand = null;
    return;
  }

  if (selectedCell) {
    const oldVal = selectedCell.textContent;
    const newVal = cell.textContent;
    updateCommandCells(selectedCommand, newVal);
    updateCommandCells(cmd, oldVal);
    selectedCell.classList.remove("highlight");
    selectedCell = null;
    selectedCommand = null;
  } else {
    selectedCell = cell;
    selectedCommand = cmd;
    cell.classList.add("highlight");
  }
}

function updateCommandCells(cmd, val) {
  if (!commandCellMap.has(cmd)) return;

  const isBtn = keymapBtnPool.includes(val) || gameBtnPool.includes(val);

  const createBtnEl = (value) => {
    const original = getOriginalLabel(value);
    const shapeClass = getBtnShapeClass(original);
    const colorClass = "btn-" + original;
    const label = labelMaps[currentMode]?.[original] ?? original;

    const wrapper = document.createElement("div");
    wrapper.style.position = "relative";
    wrapper.style.width = "100%";
    wrapper.style.height = "100%";

    const btnEl = document.createElement("div");
    btnEl.className = `inner-btn ${shapeClass} ${colorClass}`;
    btnEl.textContent = label;
    btnEl.dataset.original = original;

    wrapper.appendChild(btnEl);
    return wrapper;
  };

  commandCellMap.get(cmd).forEach((c) => {
    c.innerHTML = "";
    if (isBtn) {
      c.appendChild(createBtnEl(val));
    } else {
      c.textContent = val;
    }
  });

  if (cmd === "AIM") {
    aimButton = val;
    updateLeanBinds();
  }

  if (cmd === "RELOAD" || cmd === "INTERACT") {
    const groupVal = val;
    ["RELOAD",
      "INTERACT"].forEach((key) => {
        if (!commandCellMap.has(key)) return;
        commandCellMap.get(key).forEach((c) => {
          c.innerHTML = "";
          if (isBtn) {
            c.appendChild(createBtnEl(groupVal));
          } else {
            c.textContent = groupVal;
          }
        });
      });
  }
}

function updateLeanBinds() {
  const cells = commandCellMap.get("LEAN L/R"); if (cells) cells.forEach((c) => (c.textContent = (aimButton || "…") + " + 🕹L"));
}

function createKeymapTable() {
  keymapBtnPool.forEach((btn) => {
    const row = document.createElement("tr");
    row.setAttribute("draggable", true);

    // ▼ ドラッグ関連イベント
    row.addEventListener("dragstart", (e) => {
      e.dataTransfer.setData("text/plain", btn); // キーだけでOK
      e.dataTransfer.effectAllowed = "move";
      row.classList.add("dragging");
    });

    row.addEventListener("dragend", () => {
      row.classList.remove("dragging");
    });

    row.addEventListener("dragover", (e) => {
      e.preventDefault();
      const dragging = document.querySelector(".dragging");
      if (dragging && dragging !== row) {
        const isBelow = dragging.compareDocumentPosition(row) & Node.DOCUMENT_POSITION_FOLLOWING;
        const target = isBelow ? row: row.previousSibling;
        row.parentNode.insertBefore(dragging, target?.nextSibling || row);
      }
    });

    row.addEventListener("pointerdown",
      () => {
        row.draggable = true;
      });

    // ▼ 1列目（to列）
    const toCell = document.createElement("td");
    toCell.classList.add("btn-cell6"); // ボタン用の空セルにだけしておく
    row.appendChild(toCell);

    // ▼ 2列目～4列目（Swap, with, ■）
    for (let i = 0; i < 3; i++) {
      const cell = document.createElement("td");
      cell.classList.add("btn-cell6");

      // Swap列（2列目）だけクリックでボタン配置機能を使う
      if (i === 0) {
        if (!commandCellMap.has(btn)) {
          commandCellMap.set(btn, []);
        }
        cell.addEventListener("click", () => handleCellClick(cell, btn));
        commandCellMap.get(btn).push(cell);
      }

      row.appendChild(cell);
    }

    keymapBody.appendChild(row);
  });

  syncToColumnFromGameBody(); // ▲ → to列へ反映
  updateToCellOpacityBySwapUsage(); // Swap の使用に応じて透明度調整



/*
  // ここに追加！
  function syncToColumnFromGameBody() {
    const gameRows = gameBody.querySelectorAll("tr");
    const keymapRows = keymapBody.querySelectorAll("tr");

    gameRows.forEach((row, rowIndex) => {
      const gameCells = row.querySelectorAll("td");
      const gameBtnCell = gameCells[1]; // 【▲】列（2列目）
      const gameBtn = gameBtnCell.querySelector(".inner-btn");

      const keymapToCell = keymapRows[rowIndex]?.children[0]; // 【to】列（1列目）
      if (!keymapToCell) return;

      keymapToCell.innerHTML = ""; // 一旦空にする

      if (gameBtn) {
        const btnLabel = gameBtn.textContent.trim();
        const shapeClass = getBtnShapeClass(btnLabel);
        const colorClass = "btn-" + btnLabel;

        const innerBtn = document.createElement("div");
        innerBtn.className = `inner-btn ${shapeClass} ${colorClass}`;
        innerBtn.textContent = btnLabel;

        keymapToCell.appendChild(innerBtn);
      }
    });
  }

  function updateToCellOpacityBySwapUsage() {
    const keymapRows = keymapBody.querySelectorAll("tr");

    keymapRows.forEach((row) => {
      const toBtn = row.children[0]?.querySelector(".inner-btn");
      if (toBtn) toBtn.style.opacity = "1.0";
    });

    const usedLabels = new Set();

    keymapRows.forEach((row) => {
      const swapCell = row.children[1]; // Swap列
      const btn = swapCell.querySelector(".inner-btn");
      if (btn) {
        usedLabels.add(btn.textContent.trim());
      }
    });

    keymapRows.forEach((row) => {
      const toBtn = row.children[0]?.querySelector(".inner-btn");
      if (!toBtn) return;

      const label = toBtn.textContent.trim();
      if (usedLabels.has(label)) {
        toBtn.style.opacity = "0.5";
      }
    });
  }
*/
}

function rebuildBtnTable(master, current, tbody, type) {
  tbody.innerHTML = "";
  for (let i = 0; i < master.length; i += 2) {
    const row = document.createElement("tr");

    for (let j = 0; j < 2; j++) {
      const idx = i + j;
      const btn = master[idx];
      if (!btn) continue;

      const cell = document.createElement("td");
      cell.className = "btn";

      const shapeClass = getBtnShapeClass(btn);
      const colorClass = "btn-" + btn;

      const innerBtn = document.createElement("div");
      innerBtn.className = `inner-btn ${shapeClass} ${colorClass}`;
      innerBtn.textContent = btn;

      if (btn === "⬡") {
        innerBtn.style.opacity = "1.0";
        cell.classList.add("fixed-cell");
      } else

        if (current.includes(btn)) {
        innerBtn.style.opacity = "0.9";
        cell.addEventListener("click", () => {
          if (!selectedCell) return;

          // 1. コマンドセル側の元のボタン取得
          const oldEl = selectedCell.querySelector(".inner-btn");
          let oldVal;

          if (oldEl) {
            oldVal = oldEl.dataset.original || getOriginalLabel(oldEl.textContent.trim());
          } else {
            oldVal = getOriginalLabel(selectedCell.textContent.trim());
          }

          // 2. コマンドセルに新しいボタンを配置
          updateCommandCells(selectedCommand, btn);

          // 3. oldVal を Btn Pool に戻す（重複防止）
          if (oldVal && !current.includes(oldVal)) {
            current.push(oldVal);
          }

          // 4. 今クリックされたボタンを Btn Pool から削除
          const index = current.indexOf(btn);
          if (index > -1) current.splice(index, 1);

          // 5. 終了処理
          selectedCell.classList.remove("highlight");
          selectedCell = null;
          selectedCommand = null;

          // 6. 再描画
          rebuildBtnTable(master, current, tbody, type);
        });
      } else {
        innerBtn.style.opacity = "0.15";
        cell.addEventListener("click", () => {
          if (!selectedCell) return;

          const valEl = selectedCell.querySelector(".inner-btn");
          const val = valEl ? valEl.textContent.trim(): selectedCell.textContent.trim();

          if (val && !current.includes(val)) {
            current.push(val);
          }

          updateCommandCells(selectedCommand, "");

          selectedCell.classList.remove("highlight");
          selectedCell = null;
          selectedCommand = null;

          rebuildBtnTable(master, current, tbody, type);
        });
      }

      cell.appendChild(innerBtn);
      row.appendChild(cell);
    }

    tbody.appendChild(row);
  }
}
/*
function syncButtonsFromContainer1ToContainer2() {
  const gameTable = document.querySelector("#gameTable");
  const keymapTable = document.querySelector("#keymapTable");

  // 1. Container1の▲列のボタン情報を収集
  const container1Buttons = {};
  [...gameTable.rows].forEach(row => {
    const arrowCell = row.cells[1]; // ▲列
    if (!arrowCell) return;

    const btnEl = arrowCell.querySelector(".inner-btn");
    if (btnEl) {
      const label = btnEl.textContent.trim();
      container1Buttons[label] = label; // ラベルのみ記録
    }
  });

  // 2. Container2のto列にボタンを再構成して配置
  [...keymapTable.rows].forEach(row => {
    const toCell = row.cells[0]; // to列
    if (!toCell) return;

    const label = toCell.dataset.label?.trim();
    if (!label) return;

    if (container1Buttons[label]) {
      // 既存内容クリア
      toCell.innerHTML = "";
      toCell.classList.add("btn"); // ⬅ ボタンスタイルに必要なら追加

      // to列（1列目）
      const toCell = document.createElement("td");
      toCell.classList.add("btn"); // スタイルだけ適用、内容は空のまま
      row.appendChild(toCell);
    }
  });
}
*/

function syncToColumnFromGameBody() {
  const gameTable = gameBody.querySelectorAll("tr");
  const keymapTable = keymapBody.querySelectorAll("tr");

  gameTable.forEach((row, rowIndex) => {
    const gameCells = row.querySelectorAll("td");
    const gameBtnCell = gameCells[1]; // 【▲】列（2列目）
    const gameBtn = gameBtnCell.querySelector(".inner-btn");

    const keymapToCell = keymapTable[rowIndex]?.children[0]; // 【to】列（1列目）
    if (!keymapToCell) return;

    keymapToCell.innerHTML = ""; // 一旦空にする

    if (gameBtn) {
      const btnLabel = gameBtn.textContent.trim();
      const shapeClass = getBtnShapeClass(btnLabel);
      const colorClass = "btn-" + btnLabel;

      const innerBtn = document.createElement("div");
      innerBtn.className = `inner-btn ${shapeClass} ${colorClass}`;
      innerBtn.textContent = btnLabel;

      keymapToCell.appendChild(innerBtn);
    }
  });
}

function updateToCellOpacityBySwapUsage() {
  const keymapTable = keymapBody.querySelectorAll("tr");

  // すべてのto列のopacityを初期化（1.0）
  keymapTable.forEach((row) => {
    const toBtn = row.children[0]?.querySelector(".inner-btn");
    if (toBtn) toBtn.style.opacity = "1.0";
  });

  const usedLabels = new Set();

  // Swap列に使用されているボタンのラベルを収集
  keymapTable.forEach((row) => {
    const swapCell = row.children[1]; // Swap列
    const btn = swapCell.querySelector(".inner-btn");
    if (btn) {
      usedLabels.add(btn.textContent.trim());
    }
  });

  // to列にあるボタンのラベルがSwapで使用されていればopacityを0.5に
  keymapTable.forEach((row) => {
    const toBtn = row.children[0]?.querySelector(".inner-btn");
    if (!toBtn) return;

    const label = toBtn.textContent.trim();
    if (usedLabels.has(label)) {
      toBtn.style.opacity = "0.5";
    }
  });
}

function getBtnShapeClass(btn) {
  if (roundBtn.includes(btn)) return "shape-round";
  if (oblongBtn.includes(btn)) return "shape-oblong";
  if (squareBtn.includes(btn)) return "shape-square";
  if (macroBtn.includes(btn)) return "shape-macro";
  return "shape-square";
}

function getOriginalLabel(label) {
  for (const mode in labelMaps) {
    for (const key in labelMaps[mode]) {
      if (labelMaps[mode][key] === label) return key;
    }
  }
  return label; // fallback
}

function updateButtonLabels(mode) {
  const btns = document.querySelectorAll(".inner-btn");

  btns.forEach((btn) => {
    let original = btn.dataset.original;

    // 初回のみ保存
    if (!original) {
      original = getOriginalLabel(btn.textContent.trim());
      btn.dataset.original = original;
    }

    const mapped = labelMaps[mode]?.[original];
    btn.textContent = mapped ?? original;
  });
}

function setMode(mode) {
  currentMode = mode;
  document.body.className = `mode-${mode}`;
  updateButtonLabels(mode);
  updateCommandCellLabels(); // ←追加：セル内も更新
}

function updateCommandCellLabels() {
  for (const list of commandCellMap.values()) {
    list.forEach((cell) => {
      const btn = cell.querySelector(".inner-btn");
      if (!btn || !btn.dataset.original) return;
      const original = btn.dataset.original;
      btn.textContent = labelMaps[currentMode]?.[original] ?? original;
    });
  }
}

document.addEventListener("DOMContentLoaded", () => {
  createGameTable();
  createKeymapTable();
  rebuildBtnTable(gameBtnPool, currentGamePool, btnGameBody, "game");
  rebuildBtnTable(keymapBtnPool, currentKeymapPool, btnKeymapBody, "keymap");

  document.querySelectorAll(".mode-btn button").forEach((btn) => {
    btn.addEventListener("click", () => {
      const mode = btn.getAttribute("data-mode");
      if (!mode) return;
      setMode(mode);
    });
  });
  // poolWindow 初期非表示
  closePoolWindow5();
  closePoolWindow6();
});