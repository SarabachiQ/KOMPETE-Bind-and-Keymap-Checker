function debugLog(msg) {
  const log = document.getElementById("log");
  if (!log) return;
  const p = document.createElement("div");
  p.textContent = msg;
  log.appendChild(p);
  log.scrollTop = log.scrollHeight;
}

const NUM_BIND_CELLS = 1;

const DUAL_PLACEHOLDER = "… + 🕹L";

const gameCommands = [{
  name: "MOVE F/B/L/R",
  fixed: "🕹L"
},
  {
    name: "FIRE🔥"
  },
  {
    name: "AIM"
  },
  {
    name: "MELEE"
  },
  {
    name: "RELOAD"
  },
  {
    name: "INTERACT"
  },
  {
    name: "CROUCH/SLIDE"
  },
  {
    name: "SPRINT"
  },
  {
    name: "JUMP/EXOSUIT (HOLD)"
  },
  {
    name: "EXOSUIT"
  },
  {
    name: "SWITCH WEAPON 1"
  },
  {
    name: "SWITCH WEAPON 2",
    fixed: ""
  },
  {
    name: "EQUIP MELEE WEAPON",
    fixed: "LB"
  },
  {
    name: "EQUIP UTILITY 1",
    fixed: "RB"
  },
  {
    name: "EQUIP UTILITY 2",
    fixed: "RB"
  },
  {
    name: "EQUIP KAPSULE",
    fixed: "LB+RB"
  },
  {
    name: "LEAN L/R",
    dual: true
  },
  {
    name: "DROP ITEM"
  },
  {
    name: "PING"
  },
  {
    name: "SWITCH SHOULDER"
  },
  {
    name: "TOGGLE SCORECARD"
  },
  {
    name: "EMOTE WHEEL"
  }];

const masterBtn = [
  "btn1", "btn2", "btn3", "btn4",
  "btn5", "btn6", "btn7", "btn8",
  "btn9", "btn10", "btn11", "btn12",
  "btn13", "btn14", "btn15", "btn16",
  "btn17", "btn18", "btn19", "btn20",
  "btn21", "btn22", "btn23", "btn24",
  "btn25", "btn26", "btn27", "btn28",
  "btn29", "btn30", "btn31", "btn32"
];

const labelMaps = {
  xboxBtn: {
    X: "X",
    Y: "Y",
    A: "A",
    B: "B",
    LB: "LB",
    RB: "RB",
    LT: "LT",
    RT: "RT",
    L3: "L3",
    R3: "R3",
    M1: "M1",
    M2: "M2",
    M3: "M3",
    M4: "M4",
    "⬆": "⬆",
    "⬇": "⬇",
    "⬅": "⬅",
    "➡": "➡"
  },
  playstationBtn: {
    X: "✕",
    Y: "△",
    A: "〇",
    B: "□",
    LB: "L1",
    RB: "R1",
    LT: "L2",
    RT: "R2",
    L3: "L3",
    R3: "R3",
    M1: "M1",
    M2: "M2",
    M3: "M3",
    M4: "M4",
    "⬆": "↑",
    "⬇": "↓",
    "⬅": "←",
    "➡": "→"
  },
  switchBtn: {
    X: "XX",
    Y: "YY",
    A: "AA",
    B: "BB",
    LB: "L",
    RB: "R",
    LT: "ZL",
    RT: "ZR",
    L3: "L3",
    R3: "R3",
    M1: "M1",
    M2: "M2",
    M3: "M3",
    M4: "M4",
    "⬆": "↑",
    "⬇": "↓",
    "⬅": "←",
    "➡": "→"
  }
};

const roundBtn = ["X", "Y", "A", "B", "❐", "≡", "📷", "⬡"];
const oblongBtn = ["LB", "LT", "RB", "RT", "L3", "R3"];
const squareBtn = ["⬆", "⬇", "⬅", "➡"];
const macroBtn = ["M1", "M2", "M3", "M4"];

const gameBtnPool = [
  "X", "Y", "A", "B", "⬆", "⬇", "⬅", "➡",
  "LB", "RB", "LT", "RT", "L3", "R3",
  "❐", "≡", "📷", "⬡",
  "L🕹↑", "L🕹↓", "L🕹←", "L🕹→"
];

const keymapBtnPool = [
  "X", "Y", "A", "B", "⬆", "⬇", "⬅", "➡",
  "LB", "RB", "LT", "RT", "L3", "R3",
  "❐", "≡", "📷", "⬡", "M1", "M2", "M3", "M4"
];

const modeXbox = labelMaps.xboxBtn;
const modePlayStation = labelMaps.playstationBtn;
const modeSwitch = labelMaps.switchBtn;

let currentMode = modeXbox;

const gameBody = document.getElementById("gameBody");
const keymapBody = document.getElementById("keymapBody");
const btnGameBody = document.getElementById("btnGameBody");
const btnKeymapBody = document.getElementById("btnKeymapBody");

function updateUI() {
  document.querySelectorAll(".inner-btn").forEach(btn => {
    const masterLabel = btn.dataset.masterLabel || btn.textContent.trim();
    const converted = currentMode[masterLabel] || masterLabel;
    btn.textContent = converted;
  });
}

let selectedCell = null;
let selectedCommand = null;
let aimButton = "";
let currentGamePool = [...gameBtnPool];
let currentKeymapPool = [...keymapBtnPool];

const commandCellMap = new Map();

const container1 = document.getElementById("container1");
const container2 = document.getElementById("container2");
const poolWindow5 = document.getElementById("container5");
const poolWindow6 = document.getElementById("container6");

function setMode(mode) {
  currentMode = window[mode];
  updateUI();
}

function createGameTable() {
  console.log(gameCommands);

  gameCommands.forEach((cmd) => {
    const row = document.createElement("tr");
    row.setAttribute("draggable", true);

    const nameCell = document.createElement("td");
    nameCell.textContent = cmd.name;
    nameCell.classList.add("fixed-cell-name");
    row.appendChild(nameCell);

    for (let i = 0; i < NUM_BIND_CELLS; i++) {
      const cell = document.createElement("td");

      if (cmd.fixed !== undefined && cmd.fixed !== "") {
        const btn = document.createElement("div");
        btn.className = "inner-btn";
        btn.textContent = cmd.fixed;
        cell.classList.add("fixed-cell");
        cell.appendChild(btn);
      } else if (cmd.dual) {
        const btn = document.createElement("div");
        btn.className = "inner-btn";
        btn.textContent = DUAL_PLACEHOLDER;
        cell.classList.add("dual");
        cell.appendChild(btn);
      } else {
        cell.classList.add("btn-cell5", "active-cell");

        const btn = document.createElement("div");
        btn.className = "inner-btn";
        btn.textContent = ""; // ここは空で後から入る
        cell.appendChild(btn);

        cell.addEventListener("click", () => handleCellClick(cell));
      }

      commandCellMap.set(cell, cmd);
      row.appendChild(cell);
    }

    gameBody.appendChild(row);
  });
}

function createKeymapTable() {

  keymapBtnPool.forEach((btn) => {
    const row = document.createElement("tr");
    const toCell = document.createElement("td");
    toCell.classList.add("btn-cell6", "btn-cell6-01");
    row.appendChild(toCell);

    for (let i = 0; i < 3; i++) {
      const cell = document.createElement("td");
      const subClass = `btn-cell6-0${i + 2}`;
      cell.classList.add("btn-cell6", subClass);

      if (i === 0) {
        cell.classList.add("active-cell");
        if (!commandCellMap.has(btn)) {
          commandCellMap.set(btn, []);
        }
        cell.addEventListener("click", () => handleCellClick(cell, btn));
        commandCellMap.get(btn).push(cell);
      }

      row.appendChild(cell);
    }

    keymapBody.appendChild(row);
  });
  syncToColumnFromGameBody();
}

function rebuildBtnTable(master, current, tbody, type) {
  tbody.innerHTML = "";
  for (let i = 0; i < master.length; i += 2) {
    const row = document.createElement("tr");

    for (let j = 0; j < 2; j++) {
      const idx = i + j;
      const btn = master[idx];
      if (!btn) continue;

      const cell = document.createElement("td");
      cell.className = "btn";

      const shapeClass = getBtnShapeClass(btn);
      const colorClass = "btn-" + btn;

      const innerBtn = document.createElement("div");
      innerBtn.className = `inner-btn ${shapeClass} ${colorClass}`;
      innerBtn.textContent = btn;
      innerBtn.setAttribute("data-id", btn);

      if (btn === "⬡") {
        innerBtn.style.opacity = "1.0";
        cell.classList.add("fixed-cell");
      } else

        if (current.includes(btn)) {
        innerBtn.style.opacity = "0.9";
        cell.addEventListener("click", () => {
          if (!selectedCell) return;

          const oldEl = selectedCell.querySelector(".inner-btn");
          let oldVal;

          if (oldEl) {
            oldVal = oldEl.dataset.masterLabel || getMasterLabel(oldEl.textContent.trim());
          } else {
            oldVal = getMasterLabel(selectedCell.textContent.trim());
          }

          updateCommandCells(selectedCommand, btn);

          if (oldVal && !current.includes(oldVal)) {
            current.push(oldVal);
          }

          const index = current.indexOf(btn);
          if (index > -1) current.splice(index, 1);

          selectedCell.classList.remove("highlight");
          selectedCell = null;
          selectedCommand = null;

          rebuildBtnTable(master, current, tbody, type);

          syncToColumnFromGameBody();

        });
      } else {
        innerBtn.style.opacity = "0.15";
        cell.addEventListener("click", () => {
          if (!selectedCell) return;

          const valEl = selectedCell.querySelector(".inner-btn");
          const val = valEl ? valEl.textContent.trim(): selectedCell.textContent.trim();

          if (val && !current.includes(val)) {
            current.push(val);
          }

          updateCommandCells(selectedCommand, "");

          selectedCell.classList.remove("highlight");
          selectedCell = null;
          selectedCommand = null;

          rebuildBtnTable(master, current, tbody, type);
        });
      }

      cell.appendChild(innerBtn);
      row.appendChild(cell);
    }

    tbody.appendChild(row);
  }
}

function syncToColumnFromGameBody() {
  const gameRows = gameBody.querySelectorAll("tr");
  const keymapRows = keymapBody.querySelectorAll("tr");

  gameRows.forEach((gameRow, index) => {
    const gameCell = gameRow.cells[1];
    const keymapCell = keymapRows[index]?.cells[0];

    if (!gameCell || !keymapCell) return;

    keymapCell.innerHTML = "";
    keymapCell.className = "";

    if (gameCell.classList.contains("fixed-cell")) {
      keymapCell.classList.add("fixed-cell-copy");
    } else if (gameCell.classList.contains("dual")) {
      keymapCell.classList.add("dual");
    } else {
      keymapCell.classList.add("fixed-cell-copy");
    }

    const btn = gameCell.querySelector(".inner-btn");
    if (btn) {
      const newBtn = document.createElement("button");
      newBtn.className = "inner-btn";
      newBtn.textContent = btn.textContent;
      newBtn.disabled = true;
      newBtn.style.opacity = 0.5;
      keymapCell.appendChild(newBtn);
    }
  });
}

function closePoolWindows() {
  poolWindow5.classList.remove("show");
  poolWindow6.classList.remove("show");
}

function showPoolWindow(type) {
  closePoolWindows();
  if (type === "game") {
    poolWindow5.classList.add("show");
    poolWindow5.style.zIndex = 30;
    container2.style.zIndex = 40;
    container1.style.zIndex = 50;
    alignPopup(container3, poolWindow5);
  } else if (type === "keymap") {
    poolWindow6.classList.add("show");
    poolWindow6.style.zIndex = 20;
    container1.style.zIndex = 50;
    container2.style.zIndex = 40;
    alignPopup(container3, poolWindow6);
  }
}

function highlightCell(cell) {
  if (selectedCell) {
    selectedCell.classList.remove("highlight");
  }
  selectedCell = cell;
  selectedCommand = cell;
  cell.classList.add("highlight");
}

function handleCellClick(cell) {
  if (
    cell.classList.contains("fixed-cell-name") ||
    cell.classList.contains("fixed-cell") ||
    cell.classList.contains("fixed-cell-copy")
  ) {
    return;
  }

  document.querySelectorAll(".active-cell").forEach(c => c.classList.remove("active-cell"));
  cell.classList.add("active-cell");
  highlightCell(cell);

  const parent = cell.closest("tbody");
  if (parent === gameBody) {
    showPoolWindow("game");
  } else if (parent === keymapBody) {
    showPoolWindow("keymap");
  }
}

function selectCell(cell, cmd) {
  if (cell.classList.contains("fixed-cell") || cell.classList.contains("dual")) {
    return;
  }

  if (selectedCell === cell) {
    clearSelection();
    return;
  }

  clearSelection();
  selectedCell = cell;
  selectedCommand = cmd;
  cell.classList.add("active-cell");

  if (cell.classList.contains("btn-cell5")) {
    showContainer(container5);
  } else if (cell.classList.contains("btn-cell6") && cell.classList.contains("btn-cell6-02")) {
    showContainer(container6);
  }
}

function clearSelection() {
  if (selectedCell) {
    selectedCell.classList.remove("active-cell");
    selectedCell = null;
    selectedCommand = null;
  }
}

function updateCommandCells(cmd, val) {
  if (!commandCellMap.has(cmd)) return;

  const isBtn = keymapBtnPool.includes(val) || gameBtnPool.includes(val);

  const createBtnEl = (value) => {
    const masterLabel = getMasterLabel(value);
    const shapeClass = getBtnShapeClass(masterLabel);
    const colorClass = "btn-" + masterLabel;
    const modeTable = labelMaps[currentMode];
    const displayText = modeTable?.[masterLabel] ?? masterLabel;
  
    const wrapper = document.createElement("div");
    wrapper.className = "btn-wrapper";
  
    const btnEl = document.createElement("div");
    btnEl.className = `inner-btn ${shapeClass} ${colorClass}`;
    btnEl.textContent = displayText;
    btnEl.dataset.masterLabel = masterLabel;
  
    wrapper.appendChild(btnEl);
    return wrapper;
  };

  commandCellMap.get(cmd).forEach((c) => {
    c.innerHTML = "";
    if (isBtn) {
      c.appendChild(createBtnEl(val));
    } else {
      c.textContent = val;
    }
  });

  if (cmd === "AIM") {
    aimButton = val;
    updateLeanBinds();
  }

  if (cmd === "RELOAD" || cmd === "INTERACT") {
    const groupVal = val;
    ["RELOAD",
      "INTERACT"].forEach((key) => {
        if (!commandCellMap.has(key)) return;
        commandCellMap.get(key).forEach((c) => {
          c.innerHTML = "";
          if (isBtn) {
            c.appendChild(createBtnEl(groupVal));
          } else {
            c.textContent = groupVal;
          }
        });
      });
  }

  syncToColumnFromGameBody();
}

function updateLeanBinds() {
  const leanCells = commandCellMap.get("LEAN L/R");
  if (!leanCells) return;

  leanCells.forEach((cell) => {

    cell.innerHTML = "";

    if (aimButton instanceof HTMLElement) {

      const clone = aimButton.cloneNode(true);
      clone.classList.remove("highlight");

      cell.appendChild(clone);

      const stickIcon = document.createElement("span");
      stickIcon.textContent = " + 🕹L";
      stickIcon.style.marginLeft = "4px";
      cell.appendChild(stickIcon);

    } else {

      cell.textContent = "… + 🕹L";
    }

    syncToColumnFromGameBody();

  });
}

function getMasterLabel(label) {
  for (const mode in labelMaps) {
    for (const key in labelMaps[mode]) {
      if (labelMaps[mode][key] === label)
        return key;

    }
  }
  return label;
}

function updateButtonLabels(modeKey) {
  const btns = document.querySelectorAll(".inner-btn");

  btns.forEach((btn) => {
    const masterLabel = btn.getAttribute("data-id");

    if (!masterLabel) return;

    const mapped = labelMaps[modeKey]?.[masterLabel];
    btn.textContent = mapped ?? masterLabel;
  });
}

function alignPopup(referenceEl, popupEl) {
  const rect = referenceEl.getBoundingClientRect();
  popupEl.style.left = `${rect.right + 10}px`;
  popupEl.style.top = `${rect.top}px`;
  popupEl.classList.add("show");
}

function closeGameBtnPool() {
  const popup = document.getElementById("container5");
  if (popup) popup.classList.remove("show");
}

function closeKeymapBtnPool() {
  const popup = document.getElementById("container6");
  if (popup) popup.classList.remove("show");
}

document.addEventListener("DOMContentLoaded", () => {

  createGameTable();
  createKeymapTable();

  const container1 = document.getElementById("container1");
  const container2 = document.getElementById("container2");
  const container3 = document.getElementById("container3");

  const gameCells = gameBody.querySelectorAll(".active-cell");
  const keymapCells = keymapBody.querySelectorAll(".active-cell");

  gameCells.forEach(cell => {
    cell.addEventListener("click", () => handleCellClick(cell));
  });

  keymapCells.forEach(cell => {
    cell.addEventListener("click", () => handleCellClick(cell));
  });
});