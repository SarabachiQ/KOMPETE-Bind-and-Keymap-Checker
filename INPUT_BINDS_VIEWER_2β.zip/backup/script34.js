// script34.js

function debugLog(msg) {
  const log = document.getElementById("log"); if (!log) return; const p = document.createElement("div"); p.textContent = msg; log.appendChild(p); log.scrollTop = log.scrollHeight;
}

const NUM_BIND_CELLS = 1;

const DUAL_PLACEHOLDER = "… + 🕹L";

const gameCommands = [ {
  name: "MOVE F/B/L/R",
  fixed: "🕹L"
}, {
  name: "FIRE🔥"
}, {
  name: "AIM"
}, {
  name: "MELEE"
}, {
  name: "RELOAD"
}, {
  name: "INTERACT"
}, {
  name: "CROUCH/SLIDE"
}, {
  name: "SPRINT"
}, {
  name: "JUMP/EXOSUIT (HOLD)"
}, {
  name: "EXOSUIT"
}, {
  name: "SWITCH WEAPON 1"
}, {
  name: "SWITCH WEAPON 2",
  fixed: ""
}, {
  name: "EQUIP MELEE WEAPON",
  fixed: "LB"
}, {
  name: "EQUIP UTILITY 1",
  fixed: "RB"
}, {
  name: "EQUIP UTILITY 2",
  fixed: "RB"
}, {
  name: "EQUIP KAPSULE",
  fixed: "LB+RB"
}, {
  name: "LEAN L/R",
  dual: true
}, {
  name: "DROP ITEM"
}, {
  name: "PING"
}, {
  name: "SWITCH SHOULDER"
}, {
  name: "TOGGLE SCORECARD"
}, {
  name: "EMOTE WHEEL"
}];

// 現在の表示モード（初期値は Xbox）
let currentMode = "xbox";

const labelMaps = {
  xbox: {
    X: "X",
    Y: "Y",
    A: "A",
    B: "B",
    LB: "LB",
    RB: "RB",
    LT: "LT",
    RT: "RT",
    L3: "L3",
    R3: "R3",
    M1: "M1",
    M2: "M2",
    M3: "M3",
    M4: "M4",
    "⬆": "⬆",
    "⬇": "⬇",
    "⬅": "⬅",
    "➡": "➡"
  },
  ps: {
    X: "✕",
    Y: "△",
    A: "〇",
    B: "□",
    LB: "L1",
    RB: "R1",
    LT: "L2",
    RT: "R2",
    L3: "L3",
    R3: "R3",
    M1: "M1",
    M2: "M2",
    M3: "M3",
    M4: "M4",
    "⬆": "↑",
    "⬇": "↓",
    "⬅": "←",
    "➡": "→"
  },
  switch: {
    X: "XX",
    Y: "YY",
    A: "AA",
    B: "BB",
    LB: "L",
    RB: "R",
    LT: "ZL",
    RT: "ZR",
    L3: "L3",
    R3: "R3",
    M1: "M1",
    M2: "M2",
    M3: "M3",
    M4: "M4",
    "⬆": "↑",
    "⬇": "↓",
    "⬅": "←",
    "➡": "→"
  }
};

// ボタンの形状
const roundBtn = ["X", "Y", "A", "B", "❐", "≡", "📷", "⬡"];
const oblongBtn = ["LB", "LT", "RB", "RT", "L3", "R3"];
const squareBtn = ["⬆", "⬇", "⬅", "➡"];
const macroBtn = ["M1", "M2", "M3", "M4"];

// 各ボタンの使用先プール
const gameBtnPool = [
  "X", "Y", "A", "B", "⬆", "⬇", "⬅", "➡",
  "LB", "RB", "LT", "RT", "L3", "R3",
  "❐", "≡", "📷", "⬡",
  "L🕹↑", "L🕹↓", "L🕹←", "L🕹→"
];

const keymapCommands = [{
  name: "X"
},
  {
    name: "Y"
  },
  {
    name: "A"
  },
  {
    name: "B"
  },
  {
    name: "⬆"
  },
  {
    name: "⬇"
  },
  {
    name: "⬅"
  },
  {
    name: "➡"
  },
  {
    name: "LB"
  },
  {
    name: "RB"
  },
  {
    name: "LT"
  },
  {
    name: "RT"
  },
  {
    name: "L3"
  },
  {
    name: "R3"
  },
  {
    name: "❐"
  },
  {
    name: "≡"
  },
  {
    name: "📷"
  },
  {
    name: "⬡"
  },
  {
    name: "M1"
  },
  {
    name: "M2"
  },
  {
    name: "M3"
  },
  {
    name: "M4"
  }];

const gameBody = document.getElementById("gameBody"); // bind用テーブル本体tbody
const keymapBody = document.getElementById("keymapBody"); // keymap用テーブル本体tbody
const btnGameBody = document.getElementById("btnGameBody"); // ゲーム用プールのtbody
const btnKeymapBody = document.getElementById("btnKeymapBody"); // キーマップ用プールのtbody

let selectedCell = null; let selectedCommand = null; let aimButton = ""; let currentGamePool = [...gameBtnPool]; let currentKeymapPool = [...keymapBtnPool];

const commandCellMap = new Map();

function createGameTable() {
  gameCommands.forEach((cmd) => {
    const row = document.createElement("tr");
    row.setAttribute("draggable", true);

    // ... 既存の drag イベントなどは省略 ...

    const nameCell = document.createElement("td");
    nameCell.textContent = cmd.name;
    if (cmd.fixed !== undefined) {
      nameCell.classList.add("fixed-cell");
    }
    row.appendChild(nameCell);

    // ここは不要なので削除
    // commandCellMap.set(cmd.name, []);

    for (let i = 0; i < NUM_BIND_CELLS; i++) {
      const cell = document.createElement("td");
      if (cmd.fixed !== undefined) {
        cell.textContent = cmd.fixed;
        cell.classList.add("fixed-cell");
      } else if (cmd.dual) {
        cell.textContent = DUAL_PLACEHOLDER;
        cell.classList.add("dual");
      } else {
        cell.classList.add("btn-cell5");

        // ここでセルにクリックイベントを登録し、cmdオブジェクトを渡す
        cell.addEventListener("click", () => handleCellClick(cell, cmd));
      }

      // ここでセルをキーにしてcmdオブジェクトをセット
      commandCellMap.set(cell, cmd);

      row.appendChild(cell);
    }

    gameBody.appendChild(row);
  });
}

// --- ⑤ 各種 DOM・表示処理 ---
const container1 = document.getElementById("container1");
const container2 = document.getElementById("container2");
const poolWindow5 = document.getElementById("container5");
const poolWindow6 = document.getElementById("container6");

// ここにクリックイベント登録をまとめて書く
document.querySelectorAll("#container1 .btn-cell5").forEach(cell => {
  cell.addEventListener("click", () => handleCellClick(cell, cell));
});

document.querySelectorAll("#container2 .btn-cell6").forEach(cell => {
  cell.addEventListener("click", () => handleCellClick(cell, cell));
});

// ✅ script34.js の先頭からでOK

function alignPopup(container, popup) {
  if (!container || !popup) return;

  const rect = container.getBoundingClientRect();
  const top = rect.top + window.scrollY;
  const left = rect.left + window.scrollX;

  const orientationType = screen.orientation?.type || '';
  const isLandscape = orientationType.includes('landscape');

  popup.classList.remove("landscape", "portrait", "show");

  popup.style.top = top + "px";
  popup.style.left = left + "px";

  popup.classList.add(isLandscape ? "landscape": "portrait");

  setTimeout(() => {
    popup.classList.add("show");
  }, 10);
}

function closeGameBtnPool() {
  const popup = document.getElementById("container5");
  if (popup) popup.classList.remove("show");
}

function closeKeymapBtnPool() {
  const popup = document.getElementById("container6");
  if (popup) popup.classList.remove("show");
}

// ✅ DOMの準備が整ってから実行
document.addEventListener("DOMContentLoaded", () => {
  const container1 = document.getElementById("container1");
  const container2 = document.getElementById("container2");
  const container3 = document.getElementById("container3");
  const container5 = document.getElementById("container5");
  const container6 = document.getElementById("container6");

  function isValidBtnCell6(cell) {
    return (
      cell.classList.contains("btn-cell6") &&
      cell.classList.contains("btn-cell6-02") // ✅ ←2列目のみ許可
    );
  }

  document.addEventListener("click", (event) => {
    const cell = event.target.closest(".btn-cell5, .btn-cell6");
    if (!cell) return;

    const didSwap = handleCellClick(cell); // ✅ cmd不要になった

    if (didSwap) return; // ✅ 入れ替えだったら、ポップアップ操作スキップ

    event.stopPropagation();
    event.preventDefault();

    // ポップアップの処理はここから実行される
    if (cell.classList.contains("btn-cell5")) {
      if (!container5.classList.contains("show")) {
        console.log(">> btn-cell5 clicked. Show container5.");
        container6.classList.remove("show");
        container5.style.zIndex = 96;
        container2.style.zIndex = 97;
        container1.style.zIndex = 99;
        alignPopup(container3, container5);
      }
    }

    if (cell.classList.contains("btn-cell6") && cell.classList.contains("btn-cell6-02")) {
      if (!container6.classList.contains("show")) {
        console.log(">> btn-cell6 clicked. Show container6.");
        container5.classList.remove("show");
        container6.style.zIndex = 96;
        container1.style.zIndex = 97;
        container2.style.zIndex = 99;
        alignPopup(container3, container6);
      }
    }
  });

  // ✕以外の場所をクリックで閉じる
  document.addEventListener("click",
    (event) => {
      if (!event.target.closest(
        "#container5, .btn-cell5, #container6, .btn-cell6-01, .btn-cell6-02, .btn-cell6-03, .btn-cell6-04"
      )) {
        closeGameBtnPool();
        closeKeymapBtnPool();
      }
    });
});

function handleCellClick(cell) {
  console.log("handleCellClick called:", cell);
  console.log("cell.classList:", cell.classList);

  const isFromContainer1 = selectedCell && container1.contains(selectedCell);
  const isFromContainer2 = selectedCell && container2.contains(selectedCell);
  const isToContainer1 = container1.contains(cell);
  const isToContainer2 = container2.contains(cell);

  // ✅ 同じセルをクリック → 選択解除
  if (selectedCell === cell) {
    selectedCell.classList.remove("highlight");
    selectedCell = null;
    return false;
  }

  // ❌ container1 ⇄ container2 間の入れ替えは禁止
  if ((isFromContainer1 && isToContainer2) || (isFromContainer2 && isToContainer1)) {
    console.log("❌ container1 ⇄ container2 間の移動は禁止");

    selectedCell.classList.remove("highlight");
    selectedCell = cell;
    cell.classList.add("highlight");
    return false;
  }

  // ✅ 正常な入れ替え
  if (selectedCell) {
    const oldVal = selectedCell.textContent.trim();
    const newVal = cell.textContent.trim();

    updateCommandCells(selectedCell, newVal);
    updateCommandCells(cell, oldVal);

    selectedCell.classList.remove("highlight");
    selectedCell = null;

    return true;
  } else {
    // ✅ 初回選択
    selectedCell = cell;
    cell.classList.add("highlight");
    return false;
  }
}

function updateCommandCells(cell, val) {
  const isBtn = keymapBtnPool.includes(val) || gameBtnPool.includes(val);

  const createBtnEl = (value) => {
    const original = getOriginalLabel(value);
    const shapeClass = getBtnShapeClass(original);
    const colorClass = "btn-" + original;
    const label = labelMaps[currentMode]?.[original] ?? original;

    const wrapper = document.createElement("div");
    wrapper.style.position = "relative";
    wrapper.style.width = "100%";
    wrapper.style.height = "100%";

    const btnEl = document.createElement("div");
    btnEl.className = `inner-btn ${shapeClass} ${colorClass}`;
    btnEl.textContent = label;
    btnEl.dataset.original = original;

    wrapper.appendChild(btnEl);
    return wrapper;
  };

  // セル内を更新
  cell.innerHTML = "";
  if (isBtn) {
    cell.appendChild(createBtnEl(val));
  } else {
    cell.textContent = val;
  }

  // 特殊処理（AIM, LEANなど）は、別の仕組みで管理したほうがいいが、ひとまず維持するなら以下：
  const cellText = cell.textContent?.trim();
  if (cellText === "AIM") {
    aimButton = val;
    updateLeanBinds();
  }

  if (cellText === "RELOAD" || cellText === "INTERACT") {
    const groupVal = val;
    ["RELOAD",
      "INTERACT"].forEach((key) => {
        if (!commandCellMap.has(key)) return;
        commandCellMap.get(key).forEach((c) => {
          c.innerHTML = "";
          if (isBtn) {
            c.appendChild(createBtnEl(groupVal));
          } else {
            c.textContent = groupVal;
          }
        });
      });
  }
}

function updateLeanBinds() {
  const cells = commandCellMap.get("LEAN L/R"); if (cells) cells.forEach((c) => (c.textContent = (aimButton || "…") + " + 🕹L"));
}

function createKeymapTable() {
  keymapCommands.forEach((cmd) => {
    const row = document.createElement("tr");
    row.setAttribute("draggable", true);

    // ▼ ドラッグ関連イベント
    row.addEventListener("dragstart", (e) => {
      e.dataTransfer.setData("text/plain", cmd.name); // ✅ cmd.name を渡す
      e.dataTransfer.effectAllowed = "move";
      row.classList.add("dragging");
    });

    row.addEventListener("dragend", () => {
      row.classList.remove("dragging");
    });

    row.addEventListener("dragover", (e) => {
      e.preventDefault();
      const dragging = document.querySelector(".dragging");
      if (dragging && dragging !== row) {
        const isBelow = dragging.compareDocumentPosition(row) & Node.DOCUMENT_POSITION_FOLLOWING;
        const target = isBelow ? row: row.previousSibling;
        row.parentNode.insertBefore(dragging, target?.nextSibling || row);
      }
    });

    row.addEventListener("pointerdown",
      () => {
        row.draggable = true;
      });

    // ▼ 1列目（to列）
    const toCell = document.createElement("td");
    toCell.classList.add("btn-cell6",
      "btn-cell6-01");
    row.appendChild(toCell);

    // ▼ 2〜4列目（Swap, with, ■）
    for (let i = 0; i < 3; i++) {
      const cell = document.createElement("td");
      const subClass = `btn-cell6-0${i + 2}`;
      cell.classList.add("btn-cell6", subClass);

      if (i === 0) {
        if (!commandCellMap.has(cmd.name)) {
          commandCellMap.set(cmd.name, []);
        }
        cell.addEventListener("click", () => handleCellClick(cell, cmd));
        commandCellMap.get(cmd.name).push(cell);
      }

      row.appendChild(cell);
    }

    keymapBody.appendChild(row);
  });

  syncToColumnFromGameBody();
  updateToCellOpacityBySwapUsage();
}// Swap の使用に応じて透明度調整


function rebuildBtnTable(master, current, tbody, type) {
tbody.innerHTML = "";
for (let i = 0; i < master.length; i += 2) {
const row = document.createElement("tr");

for (let j = 0; j < 2; j++) {
const idx = i + j;
const btn = master[idx];
if (!btn) continue;

const cell = document.createElement("td");
cell.className = "btn";

const shapeClass = getBtnShapeClass(btn);
const colorClass = "btn-" + btn;

const innerBtn = document.createElement("div");
innerBtn.className = `inner-btn ${shapeClass} ${colorClass}`;
innerBtn.textContent = btn;

if (btn === "⬡") {
innerBtn.style.opacity = "1.0";
cell.classList.add("fixed-cell");
} else

if (current.includes(btn)) {
innerBtn.style.opacity = "0.9";
cell.addEventListener("click", () => {
if (!selectedCell) return;

// 1. コマンドセル側の元のボタン取得
const oldEl = selectedCell.querySelector(".inner-btn");
let oldVal;

if (oldEl) {
oldVal = oldEl.dataset.original || getOriginalLabel(oldEl.textContent.trim());
} else {
oldVal = getOriginalLabel(selectedCell.textContent.trim());
}

// 2. コマンドセルに新しいボタンを配置
updateCommandCells(selectedCommand, btn);

// 3. oldVal を Btn Pool に戻す（重複防止）
if (oldVal && !current.includes(oldVal)) {
current.push(oldVal);
}

// 4. 今クリックされたボタンを Btn Pool から削除
const index = current.indexOf(btn);
if (index > -1) current.splice(index, 1);

// 5. 終了処理
selectedCell.classList.remove("highlight");
selectedCell = null;
selectedCommand = null;

// 6. 再描画
rebuildBtnTable(master, current, tbody, type);
});
} else {
innerBtn.style.opacity = "0.15";
cell.addEventListener("click", () => {
if (!selectedCell) return;

const valEl = selectedCell.querySelector(".inner-btn");
const val = valEl ? valEl.textContent.trim(): selectedCell.textContent.trim();

if (val && !current.includes(val)) {
current.push(val);
}

updateCommandCells(selectedCommand, "");

selectedCell.classList.remove("highlight");
selectedCell = null;
selectedCommand = null;

rebuildBtnTable(master, current, tbody, type);
});
}

cell.appendChild(innerBtn);
row.appendChild(cell);
}

tbody.appendChild(row);
}
}

function syncToColumnFromGameBody() {
const gameTable = gameBody.querySelectorAll("tr");
const keymapTable = btnKeymapBody.querySelectorAll("tr");

gameTable.forEach((row, rowIndex) => {
const gameCells = row.querySelectorAll("td");
const gameBtnCell = gameCells[1]; // 【▲】列（2列目）
const gameBtn = gameBtnCell.querySelector(".inner-btn");

const keymapToCell = keymapTable[rowIndex]?.children[0]; // 【to】列（1列目）
if (!keymapToCell) return;

keymapToCell.innerHTML = ""; // 一旦空にする

if (gameBtn) {
const btnLabel = gameBtn.textContent.trim();
const shapeClass = getBtnShapeClass(btnLabel);
const colorClass = "btn-" + btnLabel;

const innerBtn = document.createElement("div");
innerBtn.className = `inner-btn ${shapeClass} ${colorClass}`;
innerBtn.textContent = btnLabel;

keymapToCell.appendChild(innerBtn);
}
});
}

function updateToCellOpacityBySwapUsage() {
const keymapTable = keymapBody.querySelectorAll("tr");

// すべてのto列のopacityを初期化（1.0）
keymapTable.forEach((row) => {
const toBtn = row.children[0]?.querySelector(".inner-btn");
if (toBtn) toBtn.style.opacity = "1.0";
});

const usedLabels = new Set();

// Swap列に使用されているボタンのラベルを収集
keymapTable.forEach((row) => {
const swapCell = row.children[1]; // Swap列
const btn = swapCell.querySelector(".inner-btn");
if (btn) {
usedLabels.add(btn.textContent.trim());
}
});

// to列にあるボタンのラベルがSwapで使用されていればopacityを0.5に
keymapTable.forEach((row) => {
const toBtn = row.children[0]?.querySelector(".inner-btn");
if (!toBtn) return;

const label = toBtn.textContent.trim();
if (usedLabels.has(label)) {
toBtn.style.opacity = "0.5";
}
});
}

function getBtnShapeClass(btn) {
if (roundBtn.includes(btn)) return "shape-round";
if (oblongBtn.includes(btn)) return "shape-oblong";
if (squareBtn.includes(btn)) return "shape-square";
if (macroBtn.includes(btn)) return "shape-macro";
return "shape-square";
}

function getOriginalLabel(label) {
for (const mode in labelMaps) {
for (const key in labelMaps[mode]) {
if (labelMaps[mode][key] === label) return key;
}
}
return label; // fallback
}

function updateButtonLabels(mode) {
const btns = document.querySelectorAll(".inner-btn");

btns.forEach((btn) => {
let original = btn.dataset.original;

// 初回のみ保存
if (!original) {
original = getOriginalLabel(btn.textContent.trim());
btn.dataset.original = original;
}

const mapped = labelMaps[mode]?.[original];
btn.textContent = mapped ?? original;
});
}

function setMode(mode) {
currentMode = mode;
document.body.className = `mode-${mode}`;
updateButtonLabels(mode);
updateCommandCellLabels(); // ←追加：セル内も更新
}

function updateCommandCellLabels() {
for (const list of commandCellMap.values()) {
list.forEach((cell) => {
const btn = cell.querySelector(".inner-btn");
if (!btn || !btn.dataset.original) return;
const original = btn.dataset.original;
btn.textContent = labelMaps[currentMode]?.[original] ?? original;
});
}
}

document.addEventListener("DOMContentLoaded", () => {
createGameTable();
createKeymapTable();
rebuildBtnTable(gameBtnPool, currentGamePool, btnGameBody, "game");
rebuildBtnTable(keymapBtnPool, currentKeymapPool, btnKeymapBody, "keymap");

document.querySelectorAll(".mode-btn button").forEach((btn) => {
btn.addEventListener("click", () => {
const mode = btn.getAttribute("data-mode");
if (!mode) return;
setMode(mode);
});
});
// poolWindow 初期非表示
closeGameBtnPool();
closeKeymapBtnPool();
});